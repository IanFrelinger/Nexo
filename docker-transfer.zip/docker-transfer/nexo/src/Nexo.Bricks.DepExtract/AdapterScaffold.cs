using System.Text;
using System.Text.RegularExpressions;

namespace Nexo.Bricks.DepExtract;

/// <summary>
/// Deterministic adapter drafts for simple parser surfaces (few classes, obvious pull APIs).
/// Used before Ollama when the source looks scaffoldable; still a starting draft for review.
/// </summary>
public static class AdapterScaffold
{
    public sealed record ClassApi(string Name, string[] Methods);

    public static bool LooksSimple(string sourceText)
    {
        var classes = ExtractClasses(sourceText);
        if (classes.Count is < 1 or > 2) return false;
        var methods = classes.SelectMany(c => c.Methods).ToArray();
        if (methods.Length is < 1 or > 8) return false;
        // Prefer surfaces that look like pull/advance/next rather than deep hierarchies.
        return methods.Any(m => m is "advance" or "next" or "nextEvent" or "read" or "pull" or "readNext");
    }

    /// <param name="entryIncludeName">Optional header basename to #include (must live on the compile include path).</param>
    public static string? TryBuild(string sourceText, string? entryIncludeName = null)
    {
        if (!LooksSimple(sourceText)) return null;
        var primary = ExtractClasses(sourceText)[0];
        var pull = primary.Methods.FirstOrDefault(m => m is "advance" or "next" or "nextEvent" or "read" or "pull" or "readNext")
            ?? primary.Methods[0];

        var pathCtor = Regex.IsMatch(
            sourceText,
            $@"\b{Regex.Escape(primary.Name)}\s*\(\s*const\s+(?:std::)?(?:filesystem::path|string)\s*&",
            RegexOptions.CultureInvariant);

        var hasLastType = primary.Methods.Any(m => m is "last_type" or "lastType");
        var includeName = string.IsNullOrWhiteSpace(entryIncludeName)
            ? null
            : entryIncludeName.Replace('\\', '/').Split('/').Last();

        var sb = new StringBuilder();
        sb.AppendLine("#pragma once");
        sb.AppendLine("// Deterministic scaffold from DepExtract (review before production use).");
        sb.AppendLine("#include \"processing.hpp\"");
        if (includeName is not null)
            sb.AppendLine($"#include \"{includeName}\"");
        sb.AppendLine("#include <memory>");
        sb.AppendLine();
        sb.AppendLine("namespace fileproc {");
        sb.AppendLine();
        sb.AppendLine("class CustomEventReader : public IEventReader {");
        sb.AppendLine("public:");
        sb.AppendLine("    explicit CustomEventReader(const std::filesystem::path& path) {");
        if (pathCtor)
        {
            sb.AppendLine($"        parser_ = std::make_unique<{primary.Name}>(path);");
        }
        else
        {
            sb.AppendLine("        // UNCERTAIN: wire ctor args from path / open proprietary handle");
            sb.AppendLine($"        (void)path; parser_ = std::make_unique<{primary.Name}>(0);");
        }
        sb.AppendLine("    }");
        sb.AppendLine("    void set_requested_fields(const std::vector<std::string>& names) override { (void)names; }");
        sb.AppendLine("    bool decodes_named_fields() const override { return true; }");
        sb.AppendLine("    bool next(Event& out, size_t max_depth) override {");
        sb.AppendLine("        (void)max_depth;");
        sb.AppendLine("        long v = 0;");
        sb.AppendLine($"        if (!parser_ || !parser_->{pull}(v)) return false;");
        if (pathCtor)
        {
            // File-backed streams often expose millisecond ticks via advance(long&).
            sb.AppendLine("        out.t = static_cast<double>(v) / 1000.0;");
        }
        else
        {
            sb.AppendLine("        out.t = static_cast<double>(v);");
        }
        if (hasLastType)
            sb.AppendLine("        out.type = static_cast<int>(parser_->last_type());");
        else
            sb.AppendLine("        out.type = 0;");
        sb.AppendLine("        out.fields[\"value\"] = std::to_string(v);");
        sb.AppendLine("        pos_++;");
        sb.AppendLine("        return true;");
        sb.AppendLine("    }");
        sb.AppendLine("    bool can_resume() const override { return true; }");
        sb.AppendLine("    uint64_t position() const override { return pos_; }");
        sb.AppendLine("    void resume_at(uint64_t off) override { pos_ = off; /* UNCERTAIN: seek proprietary stream */ }");
        sb.AppendLine("private:");
        sb.AppendLine($"    std::unique_ptr<{primary.Name}> parser_;");
        sb.AppendLine("    uint64_t pos_ = 0;");
        sb.AppendLine("};");
        sb.AppendLine();
        sb.AppendLine("inline FileInfo inspect_custom(const std::filesystem::path& path) {");
        sb.AppendLine("    FileInfo fi;");
        sb.AppendLine("    fi.bytes = std::filesystem::file_size(path);");
        sb.AppendLine("    fi.resumable = true;");
        if (pathCtor)
        {
            // Match DemoQueueReader / EVTQ taxonomy so process() accepts type ids 0..N-1.
            sb.AppendLine("    for (auto* n : kTypeNames) fi.types.push_back(n);");
            sb.AppendLine("    try {");
            sb.AppendLine($"        {primary.Name} probe(path);");
            sb.AppendLine("        fi.event_count = probe.event_count();");
            sb.AppendLine("        fi.t_begin = probe.t_begin();");
            sb.AppendLine("        fi.t_end = probe.t_end();");
            sb.AppendLine("    } catch (...) { /* leave defaults */ }");
        }
        else
        {
            sb.AppendLine("    fi.types = {\"VALUE\"};");
            sb.AppendLine("    // UNCERTAIN: fill event_count / t_begin / t_end from proprietary header");
        }
        sb.AppendLine("    return fi;");
        sb.AppendLine("}");
        sb.AppendLine();
        sb.AppendLine("inline void use_custom_reader(){");
        sb.AppendLine("    reader_factory() = [](const std::filesystem::path& p){");
        sb.AppendLine("        return std::unique_ptr<IEventReader>(new CustomEventReader(p));");
        sb.AppendLine("    };");
        sb.AppendLine("    inspect_factory() = inspect_custom;");
        sb.AppendLine("}");
        sb.AppendLine();
        sb.AppendLine("} // namespace fileproc");
        sb.AppendLine();
        return sb.ToString();
    }

    public static List<ClassApi> ExtractClasses(string source)
    {
        var list = new List<ClassApi>();
        // Allow indented closers (`\n  };`) — non-greedy body until the class terminator.
        foreach (Match m in Regex.Matches(source, @"\bclass\s+(\w+)\s*\{([\s\S]*?)\n\s*\};"))
        {
            var name = m.Groups[1].Value;
            var body = m.Groups[2].Value;
            var methods = Regex.Matches(body, @"\b(\w+)\s*\([^)]*\)\s*(?:const\s*)?(?:override\s*)?\{")
                .Select(x => x.Groups[1].Value)
                .Where(x => x is not ("if" or "while" or "for" or "switch" or "return" or "catch"))
                .Where(x => !string.Equals(x, name, StringComparison.Ordinal))
                .Distinct(StringComparer.Ordinal)
                .ToArray();
            // Also pick const getters declared with trailing const before `{`
            var getters = Regex.Matches(body, @"\b(\w+)\s*\([^)]*\)\s*const\s*\{")
                .Select(x => x.Groups[1].Value)
                .Where(x => x is not ("if" or "while" or "for" or "switch" or "return" or "catch"))
                .Distinct(StringComparer.Ordinal);
            methods = methods.Concat(getters).Distinct(StringComparer.Ordinal).ToArray();
            if (methods.Length > 0)
                list.Add(new ClassApi(name, methods));
        }
        return list;
    }
}
