using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace Nexo.Bricks.DepExtract;

/// <summary>
/// Syntax-checks an adapted_reader.hpp draft against Poco's common/ headers via Docker+g++.
/// Skips (Ok=null) when Docker or POCO_CONTEXT/common/processing.hpp is unavailable.
/// </summary>
public static class AdapterCompileGate
{
    public sealed record Result(bool? Ok, string Log, bool Skipped);

    public static async Task<Result> TryCompileAsync(
        string adapterCode,
        string? pocoContext,
        ILogger? logger = null,
        CancellationToken cancellationToken = default)
    {
        pocoContext ??= Environment.GetEnvironmentVariable("POCO_CONTEXT");
        if (string.IsNullOrWhiteSpace(pocoContext)
            || !File.Exists(Path.Combine(pocoContext, "common", "processing.hpp")))
        {
            return new Result(null, "compile gate skipped: POCO_CONTEXT/common/processing.hpp not available", Skipped: true);
        }

        pocoContext = Path.GetFullPath(pocoContext);
        DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(pocoContext, "pocoContext");

        var tmpBase = Environment.GetEnvironmentVariable("TMPDIR");
        if (string.IsNullOrWhiteSpace(tmpBase))
        {
            tmpBase = DepExtractPathRules.TryGetWorkspaceRoot() is { } ws
                ? Path.Combine(ws, ".dep-extract-out")
                : Path.GetTempPath();
        }
        var work = Path.Combine(tmpBase, "adapter-compile-" + Guid.NewGuid().ToString("n"));
        Directory.CreateDirectory(work);
        try
        {
            await File.WriteAllTextAsync(Path.Combine(work, "adapted_reader.hpp"), adapterCode, cancellationToken)
                .ConfigureAwait(false);
            await File.WriteAllTextAsync(
                Path.Combine(work, "smoke.cpp"),
                "#include \"adapted_reader.hpp\"\nint main(){return 0;}\n",
                cancellationToken).ConfigureAwait(false);

            // dep-extract image already has g++; override ENTRYPOINT to invoke g++ directly.
            var psi = new ProcessStartInfo
            {
                FileName = "docker",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            psi.ArgumentList.Add("run");
            psi.ArgumentList.Add("--rm");
            psi.ArgumentList.Add("--network=none");
            psi.ArgumentList.Add("--entrypoint");
            psi.ArgumentList.Add("g++");
            psi.ArgumentList.Add("-v");
            psi.ArgumentList.Add($"{pocoContext}/common:/common:ro");
            psi.ArgumentList.Add("-v");
            psi.ArgumentList.Add($"{work}:/work");
            psi.ArgumentList.Add("dep-extract:latest");
            psi.ArgumentList.Add("-std=c++20");
            psi.ArgumentList.Add("-fsyntax-only");
            psi.ArgumentList.Add("-I/common");
            psi.ArgumentList.Add("-I/work");
            psi.ArgumentList.Add("/work/smoke.cpp");

            using var p = Process.Start(psi);
            if (p is null)
                return new Result(null, "compile gate skipped: failed to start docker", Skipped: true);

            var stdout = await p.StandardOutput.ReadToEndAsync(cancellationToken).ConfigureAwait(false);
            var stderr = await p.StandardError.ReadToEndAsync(cancellationToken).ConfigureAwait(false);
            await p.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
            var log = (stdout + "\n" + stderr).Trim();
            if (p.ExitCode == 0)
            {
                logger?.LogInformation("Adapter compile gate passed");
                return new Result(true, string.IsNullOrWhiteSpace(log) ? "ok" : log, Skipped: false);
            }

            logger?.LogWarning("Adapter compile gate failed: {Log}", log);
            return new Result(false, log, Skipped: false);
        }
        finally
        {
            try { Directory.Delete(work, recursive: true); } catch { /* ignore */ }
        }
    }
}
