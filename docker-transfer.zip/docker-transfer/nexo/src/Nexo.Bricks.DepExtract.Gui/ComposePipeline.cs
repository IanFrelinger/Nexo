using System.Diagnostics;
using System.Text;

namespace Nexo.Bricks.DepExtract.Gui;

/// <summary>Host docker compose helpers for the parser pipeline (recreate / env upsert).</summary>
public static class ComposePipeline
{
    public static string ProjectName =>
        Environment.GetEnvironmentVariable("COMPOSE_PROJECT")
        ?? Environment.GetEnvironmentVariable("COMPOSE_PROJECT_NAME")
        ?? "nexo-parser-pipeline";

    public static string? TryFindComposeFile()
    {
        var explicitPath = Environment.GetEnvironmentVariable("PARSER_PIPELINE_COMPOSE");
        if (!string.IsNullOrWhiteSpace(explicitPath) && File.Exists(explicitPath))
            return Path.GetFullPath(explicitPath);

        var nexo = Environment.GetEnvironmentVariable("NEXO_ROOT");
        if (!string.IsNullOrWhiteSpace(nexo))
        {
            var p = Path.Combine(nexo, "docker-compose.parser-pipeline.yml");
            if (File.Exists(p)) return Path.GetFullPath(p);
        }

        var ws = Environment.GetEnvironmentVariable("WORKSPACE_ROOT");
        if (!string.IsNullOrWhiteSpace(ws))
        {
            foreach (var rel in new[] { "nexo/docker-compose.parser-pipeline.yml", "docker-compose.parser-pipeline.yml" })
            {
                var p = Path.Combine(ws, rel);
                if (File.Exists(p)) return Path.GetFullPath(p);
            }
        }

        return null;
    }

    public static async Task<ComposeRunResult> RecreateAsync(
        IReadOnlyList<string>? services,
        bool withExtractAgent,
        CancellationToken ct)
    {
        var composeFile = TryFindComposeFile()
            ?? throw new InvalidOperationException(
                "docker-compose.parser-pipeline.yml not found. Set NEXO_ROOT or PARSER_PIPELINE_COMPOSE.");
        var envFile = PortSettingsStore.ResolveEnvFilePath();
        if (envFile is null || !File.Exists(envFile))
            throw new InvalidOperationException("parser-pipeline.env missing — Apply ports or run setup first.");

        // Ensure env file has current ports from store.
        var ports = PortSettingsStore.Load();
        PortSettingsStore.Save(ports.ParserHostPort, ports.AgentHostPort);

        async Task<ComposeRunResult> RunAsync(string fileName, bool useComposeSubcommand)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            if (useComposeSubcommand)
                psi.ArgumentList.Add("compose");
            psi.ArgumentList.Add("-p");
            psi.ArgumentList.Add(ProjectName);
            psi.ArgumentList.Add("-f");
            psi.ArgumentList.Add(composeFile);
            psi.ArgumentList.Add("--env-file");
            psi.ArgumentList.Add(envFile);
            if (withExtractAgent)
            {
                psi.ArgumentList.Add("--profile");
                psi.ArgumentList.Add("extract-agent");
            }
            psi.ArgumentList.Add("up");
            psi.ArgumentList.Add("-d");
            psi.ArgumentList.Add("--force-recreate");
            if (services is { Count: > 0 })
            {
                foreach (var s in services)
                    psi.ArgumentList.Add(s);
            }

            using var p = Process.Start(psi)
                ?? throw new InvalidOperationException($"failed to start {fileName}");
            var stdout = await p.StandardOutput.ReadToEndAsync(ct);
            var stderr = await p.StandardError.ReadToEndAsync(ct);
            await p.WaitForExitAsync(ct);
            var log = (stdout + "\n" + stderr).Trim();
            return new ComposeRunResult(p.ExitCode == 0, log, ProjectName, composeFile, envFile);
        }

        var primary = await RunAsync("docker", useComposeSubcommand: true);
        if (primary.Ok) return primary;

        // Older agent images removed the Compose CLI plugin — try standalone binary.
        if (primary.Log.Contains("unknown shorthand flag", StringComparison.OrdinalIgnoreCase)
            || primary.Log.Contains("is not a docker command", StringComparison.OrdinalIgnoreCase)
            || primary.Log.Contains("compose", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                var fallback = await RunAsync("docker-compose", useComposeSubcommand: false);
                if (fallback.Ok) return fallback;
                return new ComposeRunResult(
                    false,
                    primary.Log + "\n---\n" + fallback.Log,
                    ProjectName,
                    composeFile,
                    envFile);
            }
            catch (Exception ex)
            {
                return new ComposeRunResult(
                    false,
                    primary.Log + "\n---\ndocker-compose fallback failed: " + ex.Message
                    + "\nRebuild the agent image so docker-compose-v2 is installed.",
                    ProjectName,
                    composeFile,
                    envFile);
            }
        }

        return primary;
    }
}

public sealed record ComposeRunResult(
    bool Ok,
    string Log,
    string Project,
    string ComposeFile,
    string EnvFile);
