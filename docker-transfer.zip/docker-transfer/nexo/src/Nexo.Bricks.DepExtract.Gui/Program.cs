using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json.Serialization;
using Nexo.Bricks.DepExtract;
using Nexo.Bricks.DepExtract.Gui;
using Nexo.Core.Domain.Bricks;
using Nexo.Core.Domain.Execution;
using Nexo.Infrastructure.Execution;

var plans = new ConcurrentDictionary<string, PlanSession>(StringComparer.Ordinal);
try { PlanSessionStore.LoadInto(plans); } catch { /* best-effort hydrate */ }

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IProviderFactory, ProviderFactory>();
builder.Services.AddSingleton<CppDependencyExtractorBrick>();
builder.Services.AddSingleton<CppParserAdapterBrick>();
builder.Services.ConfigureHttpJsonOptions(o =>
{
    o.SerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    o.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/status", async (IProviderFactory pf, CancellationToken ct) =>
{
    var docker = await CheckDockerAsync(ct);
    string? ollamaError = null;
    var ollama = false;
    try
    {
        await pf.EnsureOllamaReachableAsync(requireVisionModel: false, ct);
        ollama = true;
    }
    catch (Exception ex)
    {
        ollamaError = ex.Message;
    }

    var workspace = DepExtractPathRules.TryGetWorkspaceRoot();
    var poco = Environment.GetEnvironmentVariable("POCO_CONTEXT");
    var depExtractImage = await CheckDepExtractImageAsync(ct);
    var extractReady = docker.Ok && workspace is not null && depExtractImage.Ok;
    var adaptReady = extractReady && ollama;
    var ports = PortSettingsStore.Load();
    var compileGate = string.Equals(Environment.GetEnvironmentVariable("COMPILE_GATE"), "1", StringComparison.Ordinal);
    var preferScaffoldDefault = string.Equals(Environment.GetEnvironmentVariable("PREFER_SCAFFOLD"), "1", StringComparison.Ordinal);
    return Results.Json(new StatusResponse(
        docker.Ok, ollama, docker.Detail, ollamaError,
        workspace, poco, extractReady, adaptReady, depExtractImage.Detail,
        PortSettingsStore.ParserUiUrl(ports), compileGate, preferScaffoldDefault,
        ports.ParserHostPort, ports.AgentHostPort,
        PortSettingsStore.AgentUiUrl(ports),
        PortSettingsStore.ResolveEnvFilePath(),
        PortSettingsStore.TryGetEnvVar("EVTX_IMAGE") ?? Environment.GetEnvironmentVariable("EVTX_IMAGE")));
});

app.MapGet("/api/ports", () =>
{
    var ports = PortSettingsStore.Load();
    return Results.Json(new PortsResponse(
        ports.ParserHostPort,
        ports.AgentHostPort,
        PortSettingsStore.ParserUiUrl(ports),
        PortSettingsStore.AgentUiUrl(ports),
        PortSettingsStore.ResolveEnvFilePath(),
        PortSettingsStore.RestartHint(ports)));
});

app.MapPut("/api/ports", (PortsRequest req) =>
{
    try
    {
        var current = PortSettingsStore.Load();
        var parser = req.ParserHostPort ?? current.ParserHostPort;
        var agent = req.AgentHostPort ?? current.AgentHostPort;
        if (parser is < 1 or > 65535 || agent is < 1 or > 65535)
            return ApiError(400, "invalid_input", "Ports must be integers 1–65535");
        if (parser == agent)
            return ApiError(400, "invalid_input", "Parser and agent host ports must differ");

        var saved = PortSettingsStore.Save(parser, agent);
        return Results.Json(new PortsResponse(
            saved.ParserHostPort,
            saved.AgentHostPort,
            PortSettingsStore.ParserUiUrl(saved),
            PortSettingsStore.AgentUiUrl(saved),
            PortSettingsStore.ResolveEnvFilePath(),
            PortSettingsStore.RestartHint(saved)));
    }
    catch (ArgumentOutOfRangeException ex)
    {
        return ApiError(400, "invalid_input", ex.Message);
    }
    catch (Exception ex)
    {
        return ApiError(500, "ports_save_failed", ex.Message);
    }
});

/// <summary>Probe Docker + TCP and return a free parser/agent host-port pair.</summary>
app.MapGet("/api/ports/suggest", async (int? preferParser, int? preferAgent, bool? save, CancellationToken ct) =>
{
    try
    {
        var suggestion = await HostPortAllocator.SuggestAsync(
            preferParser ?? PortSettingsStore.DefaultParserHostPort,
            preferAgent ?? PortSettingsStore.DefaultAgentHostPort,
            ct);

        PortSettings? saved = null;
        if (save == true)
            saved = PortSettingsStore.Save(suggestion.ParserHostPort, suggestion.AgentHostPort);

        var ports = saved ?? new PortSettings(suggestion.ParserHostPort, suggestion.AgentHostPort);
        return Results.Json(new PortsSuggestResponse(
            ports.ParserHostPort,
            ports.AgentHostPort,
            PortSettingsStore.ParserUiUrl(ports),
            PortSettingsStore.AgentUiUrl(ports),
            PortSettingsStore.ResolveEnvFilePath(),
            saved is null ? suggestion.Summary : PortSettingsStore.RestartHint(ports),
            suggestion.PreferredParserHostPort,
            suggestion.PreferredAgentHostPort,
            suggestion.ChangedFromPreferred,
            suggestion.Summary,
            suggestion.BusySample.Take(24).ToArray(),
            saved is not null));
    }
    catch (Exception ex)
    {
        return ApiError(500, "ports_suggest_failed", ex.Message);
    }
});

/// <summary>Auto-pick free ports and persist (same as GET suggest?save=true).</summary>
app.MapPost("/api/ports/auto", async (PortsAutoRequest? req, CancellationToken ct) =>
{
    try
    {
        var current = PortSettingsStore.Load();
        var suggestion = await HostPortAllocator.SuggestAsync(
            req?.PreferParserHostPort ?? current.ParserHostPort,
            req?.PreferAgentHostPort ?? current.AgentHostPort,
            ct);
        var saved = PortSettingsStore.Save(suggestion.ParserHostPort, suggestion.AgentHostPort);
        return Results.Json(new PortsSuggestResponse(
            saved.ParserHostPort,
            saved.AgentHostPort,
            PortSettingsStore.ParserUiUrl(saved),
            PortSettingsStore.AgentUiUrl(saved),
            PortSettingsStore.ResolveEnvFilePath(),
            PortSettingsStore.RestartHint(saved),
            suggestion.PreferredParserHostPort,
            suggestion.PreferredAgentHostPort,
            suggestion.ChangedFromPreferred,
            suggestion.Summary,
            suggestion.BusySample.Take(24).ToArray(),
            true));
    }
    catch (Exception ex)
    {
        return ApiError(500, "ports_auto_failed", ex.Message);
    }
});

/// <summary>Force-recreate compose services with the current parser-pipeline.env ports.</summary>
app.MapPost("/api/ports/recreate", async (PortsRecreateRequest? req, CancellationToken ct) =>
{
    try
    {
        var withAgent = req?.WithExtractAgent ?? true;
        IReadOnlyList<string>? services = null;
        if (req?.Services is { Length: > 0 })
            services = req.Services;
        else if (req?.EvtxOnly == true)
            services = new[] { "evtx" };

        var result = await ComposePipeline.RecreateAsync(services, withAgent && req?.EvtxOnly != true, ct);
        if (!result.Ok)
            return ApiError(502, "compose_recreate_failed", result.Log);
        var ports = PortSettingsStore.Load();
        return Results.Json(new PortsRecreateResponse(
            true,
            result.Log,
            result.Project,
            result.ComposeFile,
            result.EnvFile,
            PortSettingsStore.ParserUiUrl(ports),
            PortSettingsStore.AgentUiUrl(ports)));
    }
    catch (Exception ex)
    {
        return ApiError(500, "compose_recreate_failed", ex.Message);
    }
});

app.MapGet("/api/workspace", (string? path, int? depth) =>
{
    var root = DepExtractPathRules.TryGetWorkspaceRoot();
    if (root is null)
        return ApiError(400, "invalid_input", "WORKSPACE_ROOT is not configured");

    string target;
    try
    {
        if (string.IsNullOrWhiteSpace(path) || path is "." or "/")
            target = root;
        else if (Path.IsPathRooted(path))
            target = DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(path, "path");
        else
            target = DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(Path.Combine(root, path), "path");
    }
    catch (Exception ex)
    {
        return MapException(ex, "invalid workspace path");
    }

    if (!Directory.Exists(target))
        return ApiError(404, "not_found", $"path not found: {path}");

    var maxDepth = Math.Clamp(depth ?? 2, 0, 4);
    var entries = ListWorkspace(target, root, maxDepth, 0);
    return Results.Json(new WorkspaceResponse(root, Path.GetRelativePath(root, target).Replace('\\', '/'), entries));
});

/// <summary>Extract deps + return a diagrammed adapt plan for operator approve / feedback.</summary>
app.MapPost("/api/plan", async (PlanRequest req, CppDependencyExtractorBrick extractor, ILoggerFactory logFactory, CancellationToken ct) =>
{
    var log = logFactory.CreateLogger("DepExtract.Plan");
    var prepared = PrepareRun(req.SrcDir, req.Entries);
    if (prepared.Error is { } prepErr) return prepErr;

    var extractValues = BuildExtractValues(prepared.SrcDir!, prepared.OutDir!, req.Entries!, req.ScanDir, req.IncludeDirs, req.Defines, req.IncludeUpper, manifestOnly: false);
    BrickOutput extractOut;
    try
    {
        extractOut = await extractor.ExecuteAsync(new BrickInput(extractValues), ImplementationType.Deterministic, new GuiExecutionContext(), ct);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "plan extraction failed for {SrcDir}", prepared.SrcDir);
        return MapException(ex, "extraction failed");
    }

    var lower = extractOut.Get<string[]>("lower");
    var upper = extractOut.Get<string[]>("upper");
    var external = extractOut.Get<string[]>("external");
    var manifestText = extractOut.Get<string>("manifestText");
    var extractDict = extractOut.ToDictionary();
    var duplicatePath = extractDict.TryGetValue("duplicatePath", out var dp) ? (string)dp : null;
    var bundle = AdaptPlanBuilder.TryLoadSourceBundle(prepared.SrcDir!, req.Entries!);
    var draft = AdaptPlanBuilder.Build(
        prepared.SrcDir!, req.Entries!, lower, upper, external, bundle,
        includeUpper: req.IncludeUpper);
    var preferScaffold = req.PreferScaffold
        ?? string.Equals(Environment.GetEnvironmentVariable("PREFER_SCAFFOLD"), "1", StringComparison.Ordinal);
    var requireCompile = req.RequireCompile
        ?? string.Equals(Environment.GetEnvironmentVariable("COMPILE_GATE"), "1", StringComparison.Ordinal);

    var planId = Guid.NewGuid().ToString("n")[..12];
    var session = new PlanSession(
        planId, prepared.SrcDir!, req.Entries!, req.ScanDir, req.IncludeDirs, req.Defines, req.IncludeUpper,
        preferScaffold, requireCompile, req.Model, req.MaxRetries,
        prepared.OutDir!, duplicatePath, lower, upper, external, manifestText,
        draft, new List<string>(), "proposed", DateTimeOffset.UtcNow);
    plans[planId] = session;
    PlanSessionStore.Save(session);
    log.LogInformation("Created adapt plan {PlanId} for {SrcDir} strategy={Strategy}", planId, prepared.SrcDir, draft.Strategy);
    return Results.Json(ToPlanResponse(session));
});

/// <summary>Revise a proposed plan from operator feedback (re-renders diagram + narrative).</summary>
app.MapPost("/api/plan/revise", (RevisePlanRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.PlanId))
        return ApiError(400, "invalid_input", "planId is required");
    if (!TryGetPlan(plans, req.PlanId, out var session) || session is null)
        return ApiError(404, "not_found", $"unknown planId: {req.PlanId}");
    if (session.Status is "implemented")
        return ApiError(400, "invalid_input", "plan already implemented — propose a new plan");

    var extras = new List<AdaptPlanBuilder.PlanConstraint>();
    foreach (var m in req.Must ?? [])
        if (!string.IsNullOrWhiteSpace(m)) extras.Add(new AdaptPlanBuilder.PlanConstraint("must", m.Trim()));
    foreach (var m in req.MustNot ?? [])
        if (!string.IsNullOrWhiteSpace(m)) extras.Add(new AdaptPlanBuilder.PlanConstraint("must_not", m.Trim()));

    var feedback = (req.Feedback ?? "").Trim();
    if (feedback.Length == 0 && extras.Count == 0)
        return ApiError(400, "invalid_input", "feedback or must/mustNot constraints are required");

    if (feedback.Length > 0)
        session.Feedback.Add(feedback);
    foreach (var c in extras)
        session.Feedback.Add($"{c.Kind}: {c.Text}");

    var bundle = AdaptPlanBuilder.TryLoadSourceBundle(session.SrcDir, session.Entries);
    var draft = AdaptPlanBuilder.Revise(
        session.Draft, feedback, session.SrcDir, session.Entries,
        session.Lower, session.Upper, session.External, bundle, session.Feedback,
        includeUpper: session.IncludeUpper, extraConstraints: extras);
    var revised = session with { Draft = draft, Status = "revised" };
    plans[req.PlanId] = revised;
    PlanSessionStore.Save(revised);
    return Results.Json(ToPlanResponse(revised));
});

/// <summary>Operator approved the plan — run adaptation (scaffold/model) against the stored extract.</summary>
app.MapPost("/api/plan/implement", async (ImplementPlanRequest req, CppParserAdapterBrick adapter, ILoggerFactory logFactory, CancellationToken ct) =>
{
    var log = logFactory.CreateLogger("DepExtract.Plan");
    if (string.IsNullOrWhiteSpace(req.PlanId))
        return ApiError(400, "invalid_input", "planId is required");
    if (!TryGetPlan(plans, req.PlanId, out var session) || session is null)
        return ApiError(404, "not_found", $"unknown planId: {req.PlanId}");
    if (session.DuplicatePath is null || !Directory.Exists(session.DuplicatePath))
        return ApiError(400, "invalid_input", "plan has no extract duplicate — re-run Propose plan");

    var preferScaffold = req.PreferScaffold ?? session.PreferScaffold;
    var requireCompile = req.RequireCompile ?? session.RequireCompile;
    var adaptValues = new Dictionary<string, object>
    {
        ["parserDir"] = session.DuplicatePath,
        ["entryFiles"] = session.Entries,
        ["outputPath"] = Path.Combine(session.OutDir, "adapted_reader.hpp"),
        ["requireCompile"] = requireCompile,
        ["preferScaffold"] = preferScaffold,
        ["operatorGuidance"] = session.Draft.OperatorGuidance,
    };
    if (!string.IsNullOrWhiteSpace(req.Model ?? session.Model)) adaptValues["model"] = (req.Model ?? session.Model)!;
    if ((req.MaxRetries ?? session.MaxRetries) is { } mr) adaptValues["maxRetries"] = mr;
    var poco = Environment.GetEnvironmentVariable("POCO_CONTEXT");
    if (!string.IsNullOrWhiteSpace(poco)) adaptValues["pocoContext"] = poco;

    BrickOutput adaptOut;
    try
    {
        adaptOut = await adapter.ExecuteAsync(new BrickInput(adaptValues), ImplementationType.Agentic, new GuiExecutionContext(), ct);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "plan implement failed for {PlanId}", req.PlanId);
        return MapException(ex, "adaptation failed", new Dictionary<string, object?>
        {
            ["planId"] = session.PlanId,
            ["lower"] = session.Lower,
            ["upper"] = session.Upper,
            ["external"] = session.External,
            ["manifestText"] = session.ManifestText,
            ["duplicatePath"] = session.DuplicatePath,
        });
    }

    bool? compileOk = null;
    string? compileLog = null;
    var adaptDict = adaptOut.ToDictionary();
    if (adaptDict.TryGetValue("compileOk", out var co) && co is bool cob) compileOk = cob;
    if (adaptDict.TryGetValue("compileLog", out var cl) && cl is string cls) compileLog = cls;

    var done = session with { Status = "implemented" };
    plans[req.PlanId] = done;
    PlanSessionStore.Save(done);

    return Results.Json(new RunResponse(
        session.Lower, session.Upper, session.External, session.ManifestText, session.DuplicatePath,
        adaptOut.Get<string>("adapterCode"),
        adaptOut.Get<string>("outputPath"),
        adaptOut.Get<double>("sourceApiCoverage"),
        adaptOut.Get<bool>("looksLikeTemplateEcho"),
        adaptOut.Get<string[]>("possibleHallucinations"),
        adaptOut.Summary ?? "",
        compileOk,
        compileLog,
        session.PlanId));
});

app.MapGet("/api/plan/{planId}", (string planId) =>
{
    if (!TryGetPlan(plans, planId, out var session) || session is null)
        return ApiError(404, "not_found", $"unknown planId: {planId}");
    return Results.Json(ToPlanResponse(session));
});

app.MapGet("/api/plan/{planId}/export.md", (string planId) =>
{
    if (!TryGetPlan(plans, planId, out var session) || session is null)
        return ApiError(404, "not_found", $"unknown planId: {planId}");
    var md = AdaptPlanBuilder.ToMarkdown(session.Draft, session.PlanId, session.Status, session.Feedback);
    var exportPath = Path.Combine(PlanSessionStore.ResolvePlansDirectory(), session.PlanId + ".md");
    File.WriteAllText(exportPath, md);
    return Results.Text(md, "text/markdown", System.Text.Encoding.UTF8);
});

app.MapPost("/api/run", async (RunRequest req, CppDependencyExtractorBrick extractor, CppParserAdapterBrick adapter, ILoggerFactory logFactory, CancellationToken ct) =>
{
    var log = logFactory.CreateLogger("DepExtract.Agent");
    if (string.IsNullOrWhiteSpace(req.SrcDir))
        return ApiError(400, "invalid_input", "srcDir is required");
    if (!Directory.Exists(req.SrcDir))
        return ApiError(404, "not_found", $"srcDir not found: {req.SrcDir}");
    if (req.Entries is null || req.Entries.Length == 0)
        return ApiError(400, "invalid_input", "at least one entry file is required");

    string srcDir;
    try
    {
        srcDir = DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(req.SrcDir, "srcDir");
    }
    catch (Exception ex)
    {
        return MapException(ex, "invalid srcDir");
    }

    var tmpBase = Environment.GetEnvironmentVariable("TMPDIR");
    if (string.IsNullOrWhiteSpace(tmpBase))
    {
        tmpBase = DepExtractPathRules.TryGetWorkspaceRoot() is { } ws
            ? Path.Combine(ws, ".dep-extract-out")
            : Path.GetTempPath();
    }
    Directory.CreateDirectory(tmpBase);
    var outDir = Path.Combine(tmpBase, "dep-extract-gui-" + Guid.NewGuid());
    try
    {
        DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(outDir, "outDir");
    }
    catch (Exception ex)
    {
        return MapException(ex, "invalid outDir");
    }

    var ctx = new GuiExecutionContext();
    var extractValues = new Dictionary<string, object>
    {
        ["srcDir"] = srcDir,
        ["outDir"] = outDir,
        ["entries"] = req.Entries,
    };
    if (!string.IsNullOrWhiteSpace(req.ScanDir)) extractValues["scanDir"] = req.ScanDir!;
    if (req.IncludeDirs is { Length: > 0 }) extractValues["includeDirs"] = req.IncludeDirs;
    if (req.Defines is { Length: > 0 }) extractValues["defines"] = req.Defines;
    if (req.IncludeUpper) extractValues["includeUpper"] = true;
    if (req.ManifestOnly) extractValues["manifestOnly"] = true;

    BrickOutput extractOut;
    try
    {
        extractOut = await extractor.ExecuteAsync(new BrickInput(extractValues), ImplementationType.Deterministic, ctx, ct);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "extraction failed for {SrcDir}", srcDir);
        return MapException(ex, "extraction failed");
    }

    var lower = extractOut.Get<string[]>("lower");
    var upper = extractOut.Get<string[]>("upper");
    var external = extractOut.Get<string[]>("external");
    var manifestText = extractOut.Get<string>("manifestText");
    var extractDict = extractOut.ToDictionary();
    var duplicatePath = extractDict.TryGetValue("duplicatePath", out var dp) ? (string)dp : null;

    if (req.ManifestOnly || req.ExtractOnly || duplicatePath is null)
    {
        return Results.Json(new RunResponse(lower, upper, external, manifestText, duplicatePath,
            null, null, null, null, null, extractOut.Summary ?? "", null, null, null));
    }

    var requireCompile = req.RequireCompile
        ?? string.Equals(Environment.GetEnvironmentVariable("COMPILE_GATE"), "1", StringComparison.Ordinal);
    var preferScaffold = req.PreferScaffold
        ?? string.Equals(Environment.GetEnvironmentVariable("PREFER_SCAFFOLD"), "1", StringComparison.Ordinal);
    var adaptValues = new Dictionary<string, object>
    {
        ["parserDir"] = duplicatePath,
        ["entryFiles"] = req.Entries,
        ["outputPath"] = Path.Combine(outDir, "adapted_reader.hpp"),
        ["requireCompile"] = requireCompile,
        ["preferScaffold"] = preferScaffold,
    };
    if (!string.IsNullOrWhiteSpace(req.Model)) adaptValues["model"] = req.Model!;
    if (req.MaxRetries is { } mr) adaptValues["maxRetries"] = mr;
    var poco = Environment.GetEnvironmentVariable("POCO_CONTEXT");
    if (!string.IsNullOrWhiteSpace(poco)) adaptValues["pocoContext"] = poco;

    BrickOutput adaptOut;
    try
    {
        adaptOut = await adapter.ExecuteAsync(new BrickInput(adaptValues), ImplementationType.Agentic, ctx, ct);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "adaptation failed for {SrcDir}", srcDir);
        return MapException(ex, "adaptation failed", new Dictionary<string, object?>
        {
            ["lower"] = lower,
            ["upper"] = upper,
            ["external"] = external,
            ["manifestText"] = manifestText,
            ["duplicatePath"] = duplicatePath,
        });
    }

    bool? compileOk = null;
    string? compileLog = null;
    var adaptDict = adaptOut.ToDictionary();
    if (adaptDict.TryGetValue("compileOk", out var co) && co is bool cob)
        compileOk = cob;
    if (adaptDict.TryGetValue("compileLog", out var cl) && cl is string cls)
        compileLog = cls;

    return Results.Json(new RunResponse(
        lower, upper, external, manifestText, duplicatePath,
        adaptOut.Get<string>("adapterCode"),
        adaptOut.Get<string>("outputPath"),
        adaptOut.Get<double>("sourceApiCoverage"),
        adaptOut.Get<bool>("looksLikeTemplateEcho"),
        adaptOut.Get<string[]>("possibleHallucinations"),
        adaptOut.Summary ?? "",
        compileOk,
        compileLog,
        null));
});

/// <summary>Install a drafted adapter into Poco and optionally rebuild the custom evtx image.</summary>
app.MapPost("/api/install", async (InstallRequest req, ILoggerFactory logFactory, CancellationToken ct) =>
{
    var log = logFactory.CreateLogger("DepExtract.Install");
    try
    {
        var poco = string.IsNullOrWhiteSpace(req.PocoContext)
            ? Environment.GetEnvironmentVariable("POCO_CONTEXT")
            : req.PocoContext;
        if (string.IsNullOrWhiteSpace(poco))
            return ApiError(400, "invalid_input", "pocoContext is required (or set POCO_CONTEXT)");
        poco = DepExtractPathRules.RequireExistingDirectory(poco, "pocoContext");
        DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(poco, "pocoContext");
        if (!File.Exists(Path.Combine(poco, "poco", "main.cpp")))
            return ApiError(400, "invalid_input", "pocoContext does not look like the Poco/evtx tree (missing poco/main.cpp)");

        string code;
        if (!string.IsNullOrWhiteSpace(req.AdapterCode))
        {
            code = req.AdapterCode!;
        }
        else if (!string.IsNullOrWhiteSpace(req.AdapterPath))
        {
            var path = DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(req.AdapterPath!, "adapterPath");
            if (!File.Exists(path))
                return ApiError(404, "not_found", $"adapterPath not found: {path}");
            code = await File.ReadAllTextAsync(path, ct);
        }
        else
        {
            return ApiError(400, "invalid_input", "adapterCode or adapterPath is required");
        }

        var dest = Path.Combine(poco, "common", "adapted_reader.hpp");
        await File.WriteAllTextAsync(dest, code, ct);
        log.LogInformation("Wrote adapter to {Dest}", dest);

        var companions = new List<string>();
        var writtenLeaves = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // Explicit companions win; then auto-copy from plan duplicate/lower/entries.
        if (req.CompanionFiles is { Length: > 0 })
        {
            foreach (var c in req.CompanionFiles)
            {
                if (c is null || string.IsNullOrWhiteSpace(c.Name) || c.Content is null) continue;
                var leaf = Path.GetFileName(c.Name.Replace('\\', '/'));
                if (string.IsNullOrWhiteSpace(leaf) || leaf.Contains("..", StringComparison.Ordinal))
                    return ApiError(400, "invalid_input", $"invalid companion file name: {c.Name}");
                var companionDest = Path.Combine(poco, "common", leaf);
                await File.WriteAllTextAsync(companionDest, c.Content, ct);
                companions.Add(companionDest);
                writtenLeaves.Add(leaf);
                log.LogInformation("Wrote companion source {Dest}", companionDest);
            }
        }

        PlanSession? planSession = null;
        if (!string.IsNullOrWhiteSpace(req.PlanId) && TryGetPlan(plans, req.PlanId!, out var sess))
            planSession = sess;

        if (planSession?.DuplicatePath is { } dupRoot && Directory.Exists(dupRoot))
        {
            var autoNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var e in planSession.Entries ?? Array.Empty<string>())
            {
                var leaf = Path.GetFileName(e.Replace('\\', '/'));
                if (!string.IsNullOrWhiteSpace(leaf)) autoNames.Add(leaf);
            }
            foreach (var l in planSession.Lower ?? Array.Empty<string>())
            {
                var leaf = Path.GetFileName(l.Replace('\\', '/'));
                if (!string.IsNullOrWhiteSpace(leaf)) autoNames.Add(leaf);
            }
            // Also pull quoted includes from the adapter body.
            foreach (System.Text.RegularExpressions.Match m in
                     System.Text.RegularExpressions.Regex.Matches(code, "#\\s*include\\s*\"([^\"]+)\""))
            {
                var leaf = Path.GetFileName(m.Groups[1].Value.Replace('\\', '/'));
                if (!string.IsNullOrWhiteSpace(leaf)) autoNames.Add(leaf);
            }

            foreach (var leaf in autoNames)
            {
                if (writtenLeaves.Contains(leaf)) continue;
                if (!IsCompanionLeaf(leaf)) continue;
                var src = FindUnder(dupRoot, leaf);
                if (src is null) continue;
                var companionDest = Path.Combine(poco, "common", leaf);
                File.Copy(src, companionDest, overwrite: true);
                companions.Add(companionDest);
                writtenLeaves.Add(leaf);
                log.LogInformation("Auto-copied companion {Src} → {Dest}", src, companionDest);
            }
        }

        string? imageTag = null;
        string? buildLog = null;
        if (req.RebuildImage)
        {
            imageTag = string.IsNullOrWhiteSpace(req.ImageTag) ? "evtx:custom" : req.ImageTag!;
            var psi = new ProcessStartInfo
            {
                FileName = "docker",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            psi.ArgumentList.Add("build");
            psi.ArgumentList.Add("-f");
            psi.ArgumentList.Add("Dockerfile.custom");
            psi.ArgumentList.Add("-t");
            psi.ArgumentList.Add(imageTag);
            psi.ArgumentList.Add(".");
            psi.WorkingDirectory = poco;
            using var p = Process.Start(psi)
                ?? throw DepExtractException.DockerUnavailable("failed to start docker build");
            var stdout = await p.StandardOutput.ReadToEndAsync(ct);
            var stderr = await p.StandardError.ReadToEndAsync(ct);
            await p.WaitForExitAsync(ct);
            buildLog = (stdout + "\n" + stderr).Trim();
            if (p.ExitCode != 0)
                return ApiError(502, "build_failed", $"docker build failed:\n{buildLog}");

            // Point the live compose stack at the custom image.
            PortSettingsStore.UpsertEnvVar("EVTX_IMAGE", imageTag);
        }

        string? recreateLog = null;
        var recreate = req.RecreateEvtx ?? req.RebuildImage;
        if (recreate && !string.IsNullOrWhiteSpace(imageTag))
        {
            try
            {
                var result = await ComposePipeline.RecreateAsync(new[] { "evtx" }, withExtractAgent: false, ct);
                recreateLog = result.Log;
                if (!result.Ok)
                    log.LogWarning("evtx recreate after install failed: {Log}", result.Log);
            }
            catch (Exception ex)
            {
                recreateLog = ex.Message;
                log.LogWarning(ex, "evtx recreate after install skipped");
            }
        }

        var parserUiUrl = PortSettingsStore.ParserUiUrl();
        var summary = companions.Count == 0
            ? "Adapter installed. Open the Poco parser GUI to run extractions."
            : $"Adapter installed with {companions.Count} companion source(s). Open the Poco parser GUI to run extractions.";
        if (!string.IsNullOrWhiteSpace(imageTag))
            summary += $" EVTX_IMAGE={imageTag}.";
        return Results.Json(new InstallResponse(dest, imageTag, buildLog, parserUiUrl, summary, companions.ToArray(), recreateLog));
    }
    catch (Exception ex)
    {
        log.LogError(ex, "install failed");
        return MapException(ex, "install failed");
    }
});

app.Run(Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? "http://0.0.0.0:5237");

static PreparedRun PrepareRun(string? srcDirReq, string[]? entries)
{
    if (string.IsNullOrWhiteSpace(srcDirReq))
        return new PreparedRun(ApiError(400, "invalid_input", "srcDir is required"), null, null);
    if (!Directory.Exists(srcDirReq))
        return new PreparedRun(ApiError(404, "not_found", $"srcDir not found: {srcDirReq}"), null, null);
    if (entries is null || entries.Length == 0)
        return new PreparedRun(ApiError(400, "invalid_input", "at least one entry file is required"), null, null);

    string srcDir;
    try { srcDir = DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(srcDirReq, "srcDir"); }
    catch (Exception ex) { return new PreparedRun(MapException(ex, "invalid srcDir"), null, null); }

    var tmpBase = Environment.GetEnvironmentVariable("TMPDIR");
    if (string.IsNullOrWhiteSpace(tmpBase))
    {
        tmpBase = DepExtractPathRules.TryGetWorkspaceRoot() is { } ws
            ? Path.Combine(ws, ".dep-extract-out")
            : Path.GetTempPath();
    }
    Directory.CreateDirectory(tmpBase);
    var outDir = Path.Combine(tmpBase, "dep-extract-gui-" + Guid.NewGuid());
    try { DepExtractPathRules.EnsureUnderWorkspaceRootIfConfigured(outDir, "outDir"); }
    catch (Exception ex) { return new PreparedRun(MapException(ex, "invalid outDir"), null, null); }

    return new PreparedRun(null, srcDir, outDir);
}

static Dictionary<string, object> BuildExtractValues(
    string srcDir, string outDir, string[] entries, string? scanDir, string[]? includeDirs, string[]? defines,
    bool includeUpper, bool manifestOnly)
{
    var extractValues = new Dictionary<string, object>
    {
        ["srcDir"] = srcDir,
        ["outDir"] = outDir,
        ["entries"] = entries,
    };
    if (!string.IsNullOrWhiteSpace(scanDir)) extractValues["scanDir"] = scanDir!;
    if (includeDirs is { Length: > 0 }) extractValues["includeDirs"] = includeDirs;
    if (defines is { Length: > 0 }) extractValues["defines"] = defines;
    if (includeUpper) extractValues["includeUpper"] = true;
    if (manifestOnly) extractValues["manifestOnly"] = true;
    return extractValues;
}

static bool TryGetPlan(ConcurrentDictionary<string, PlanSession> plans, string planId, out PlanSession? session)
{
    if (plans.TryGetValue(planId, out session))
        return true;
    session = PlanSessionStore.TryLoad(planId);
    if (session is null) return false;
    plans[planId] = session;
    return true;
}

static bool IsCompanionLeaf(string leaf)
{
    var ext = Path.GetExtension(leaf);
    return ext is ".hpp" or ".h" or ".hh" or ".hxx" or ".cpp" or ".cc" or ".cxx" or ".c";
}

static string? FindUnder(string root, string leaf)
{
    try
    {
        return Directory.EnumerateFiles(root, leaf, SearchOption.AllDirectories).FirstOrDefault();
    }
    catch
    {
        return null;
    }
}

static PlanResponse ToPlanResponse(PlanSession s) => new(
    s.PlanId,
    s.Status,
    s.Draft.Title,
    s.Draft.StructureSummary,
    s.Draft.AdaptationSummary,
    s.Draft.Steps.ToArray(),
    s.Draft.Strategy,
    s.Draft.DiagramMermaid,
    s.Draft.Diagram,
    s.Draft.Classes.Select(c => new PlanClassDto(c.Name, c.Methods)).ToArray(),
    s.Draft.Risks.Select(r => new PlanRiskDto(r.Code, r.Severity, r.Message)).ToArray(),
    s.Draft.Constraints.Select(c => new PlanConstraintDto(c.Kind, c.Text)).ToArray(),
    s.Lower, s.Upper, s.External, s.ManifestText, s.DuplicatePath,
    s.Feedback.ToArray(),
    s.CreatedAt,
    "Review risks and constraints. Approve to implement, or revise with Must / Must not feedback.",
    $"/api/plan/{s.PlanId}/export.md");

static IResult ApiError(int status, string code, string detail, IDictionary<string, object?>? extras = null) =>
    Results.Json(new ErrorResponse(code, detail, extras), statusCode: status);

static IResult MapException(Exception ex, string title, IDictionary<string, object?>? extras = null)
{
    if (ex is DepExtractException de)
        return ApiError(de.SuggestedStatusCode, de.Code, de.Message, extras);

    return ex switch
    {
        ArgumentException or ArgumentNullException => ApiError(400, "invalid_input", ex.Message, extras),
        DirectoryNotFoundException or FileNotFoundException => ApiError(404, "not_found", ex.Message, extras),
        OperationCanceledException => ApiError(499, "cancelled", "Request was cancelled.", extras),
        _ => ApiError(500, "internal_error", $"{title}: {ex.Message}", extras)
    };
}

static async Task<DockerStatus> CheckDockerAsync(CancellationToken ct)
{
    try
    {
        var psi = new ProcessStartInfo
        {
            FileName = "docker",
            ArgumentList = { "version", "--format", "{{.Server.Version}}" },
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        using var p = Process.Start(psi);
        if (p is null) return new DockerStatus(false, "failed to start docker process");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(5));
        try
        {
            await p.WaitForExitAsync(timeout.Token);
        }
        catch (OperationCanceledException)
        {
            try { p.Kill(entireProcessTree: true); } catch { /* ignore */ }
            return new DockerStatus(false, "docker version timed out");
        }
        var stdout = await p.StandardOutput.ReadToEndAsync(ct);
        var stderr = await p.StandardError.ReadToEndAsync(ct);
        if (p.ExitCode != 0)
            return new DockerStatus(false, string.IsNullOrWhiteSpace(stderr) ? $"exit {p.ExitCode}" : stderr.Trim());
        return new DockerStatus(true, string.IsNullOrWhiteSpace(stdout) ? "ok" : stdout.Trim());
    }
    catch (Exception ex)
    {
        return new DockerStatus(false, ex.Message);
    }
}

static async Task<DockerStatus> CheckDepExtractImageAsync(CancellationToken ct)
{
    try
    {
        var psi = new ProcessStartInfo
        {
            FileName = "docker",
            ArgumentList = { "image", "inspect", "dep-extract:latest", "--format", "{{.Id}}" },
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        using var p = Process.Start(psi);
        if (p is null) return new DockerStatus(false, "failed to start docker");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(5));
        try { await p.WaitForExitAsync(timeout.Token); }
        catch (OperationCanceledException)
        {
            try { p.Kill(entireProcessTree: true); } catch { /* ignore */ }
            return new DockerStatus(false, "image inspect timed out");
        }
        if (p.ExitCode != 0)
            return new DockerStatus(false, "dep-extract:latest image missing — build tools/dep_extract");
        var id = (await p.StandardOutput.ReadToEndAsync(ct)).Trim();
        return new DockerStatus(true, string.IsNullOrWhiteSpace(id) ? "present" : id);
    }
    catch (Exception ex)
    {
        return new DockerStatus(false, ex.Message);
    }
}

static List<WorkspaceEntry> ListWorkspace(string dir, string root, int maxDepth, int depth)
{
    var list = new List<WorkspaceEntry>();
    IEnumerable<string> dirs;
    IEnumerable<string> files;
    try
    {
        dirs = Directory.EnumerateDirectories(dir).OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase);
        files = Directory.EnumerateFiles(dir).OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase);
    }
    catch
    {
        return list;
    }

    foreach (var d in dirs.Take(200))
    {
        var name = Path.GetFileName(d);
        if (name is "bin" or "obj" or ".git" or "node_modules") continue;
        var rel = Path.GetRelativePath(root, d).Replace('\\', '/');
        list.Add(new WorkspaceEntry(rel, name, true, null));
        if (depth < maxDepth)
            list.AddRange(ListWorkspace(d, root, maxDepth, depth + 1));
    }
    foreach (var f in files.Take(400))
    {
        var name = Path.GetFileName(f);
        var rel = Path.GetRelativePath(root, f).Replace('\\', '/');
        list.Add(new WorkspaceEntry(rel, name, false, new FileInfo(f).Length));
    }
    return list;
}

sealed record DockerStatus(bool Ok, string Detail);
sealed record StatusResponse(
    bool Docker, bool Ollama, string? DockerDetail, string? OllamaError,
    string? WorkspaceRoot, string? PocoContext, bool ExtractReady, bool AdaptReady,
    string? DepExtractImageDetail,
    string? ParserUiUrl, bool CompileGateDefault, bool PreferScaffoldDefault,
    int ParserHostPort = PortSettingsStore.DefaultParserHostPort,
    int AgentHostPort = PortSettingsStore.DefaultAgentHostPort,
    string? AgentUiUrl = null,
    string? PortsEnvFile = null,
    string? EvtxImage = null);

sealed record PortsRequest(int? ParserHostPort, int? AgentHostPort);

sealed record PortsAutoRequest(int? PreferParserHostPort, int? PreferAgentHostPort);

sealed record PortsRecreateRequest(bool? WithExtractAgent, bool? EvtxOnly, string[]? Services);

sealed record PortsRecreateResponse(
    bool Ok,
    string Log,
    string Project,
    string ComposeFile,
    string EnvFile,
    string ParserUiUrl,
    string AgentUiUrl);

sealed record PortsResponse(
    int ParserHostPort,
    int AgentHostPort,
    string ParserUiUrl,
    string AgentUiUrl,
    string? EnvFile,
    string RestartHint);

sealed record PortsSuggestResponse(
    int ParserHostPort,
    int AgentHostPort,
    string ParserUiUrl,
    string AgentUiUrl,
    string? EnvFile,
    string RestartHint,
    int PreferredParserHostPort,
    int PreferredAgentHostPort,
    bool ChangedFromPreferred,
    string Summary,
    int[] BusySample,
    bool Saved);
sealed record ErrorResponse(string Error, string Detail, IDictionary<string, object?>? Extras = null);
sealed record WorkspaceEntry(string Path, string Name, bool IsDir, long? SizeBytes);
sealed record WorkspaceResponse(string WorkspaceRoot, string RelativePath, IReadOnlyList<WorkspaceEntry> Entries);

sealed record RunRequest(
    string SrcDir,
    string[] Entries,
    string? ScanDir,
    string[]? IncludeDirs,
    string[]? Defines,
    bool IncludeUpper,
    bool ManifestOnly,
    bool ExtractOnly,
    string? Model,
    int? MaxRetries,
    bool? RequireCompile,
    bool? PreferScaffold);

sealed record RunResponse(
    string[] Lower,
    string[] Upper,
    string[] External,
    string ManifestText,
    string? DuplicatePath,
    string? AdapterCode,
    string? AdapterOutputPath,
    double? SourceApiCoverage,
    bool? LooksLikeTemplateEcho,
    string[]? PossibleHallucinations,
    string Summary,
    bool? CompileOk,
    string? CompileLog,
    string? PlanId = null);

sealed record PreparedRun(IResult? Error, string? SrcDir, string? OutDir);

sealed record CompanionFile(string Name, string Content);

sealed record InstallRequest(
    string? AdapterCode,
    string? AdapterPath,
    string? PocoContext,
    bool RebuildImage,
    string? ImageTag,
    CompanionFile[]? CompanionFiles = null,
    string? PlanId = null,
    bool? RecreateEvtx = null);

sealed record InstallResponse(
    string AdaptedReaderPath,
    string? ImageTag,
    string? BuildLog,
    string ParserUiUrl,
    string Summary,
    string[]? CompanionPaths = null,
    string? RecreateLog = null);

sealed class GuiExecutionContext : IExecutionContext
{
    public string AgentId => "dep-extract-agent";
    public string BehaviorId => "run";
    public bool IsAirGapped => true;
    public bool AuditMode => false;
    public string Provider => "ollama";
    public IReadOnlyDictionary<string, object> Variables { get; } = new Dictionary<string, object>();
}

/// <summary>Exposes the top-level-statement Program to WebApplicationFactory&lt;Program&gt; for integration tests.</summary>
public partial class Program { }
