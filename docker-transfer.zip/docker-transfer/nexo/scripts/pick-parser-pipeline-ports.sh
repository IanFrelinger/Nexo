#!/usr/bin/env bash
# Pick free host ports for the parser pipeline and write parser-pipeline.env.
#
#   eval "$(bash scripts/pick-parser-pipeline-ports.sh)"
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROBE="$ROOT/scripts/probe-parser-pipeline-ports.sh"
WS="${WORKSPACE_ROOT:-${HOME}/work}"
PREFER_PARSER="${EVTX_HOST_PORT:-18080}"
PREFER_AGENT="${AGENT_PORT:-${GUI_PORT:-5237}}"
OUT="${PARSER_PIPELINE_ENV:-${WS}/parser-pipeline.env}"
KEEP_IMAGE="${EVTX_IMAGE:-}"

mkdir -p "$WS"

port_busy() {
  bash "$PROBE" "$1"
}

pick_free() {
  local start="$1" skip="${2:-}"
  local p
  for p in $(seq "$start" $((start + 200))) $(seq 28080 28280) $(seq 15237 15437); do
    [ "$p" = "$skip" ] && continue
    if ! port_busy "$p"; then
      echo "$p"
      return 0
    fi
  done
  echo "error: no free port near $start" >&2
  return 1
}

PARSER="$(pick_free "$PREFER_PARSER")"
AGENT="$(pick_free "$PREFER_AGENT" "$PARSER")"

{
  echo "# Auto-picked by scripts/pick-parser-pipeline-ports.sh"
  echo "EVTX_HOST_PORT=${PARSER}"
  echo "AGENT_PORT=${AGENT}"
  echo "GUI_PORT=${AGENT}"
  if [ -n "$KEEP_IMAGE" ]; then
    echo "EVTX_IMAGE=${KEEP_IMAGE}"
  fi
  if [ -n "${COMPOSE_PROJECT:-}" ]; then
    echo "COMPOSE_PROJECT=${COMPOSE_PROJECT}"
  fi
  if [ -n "${NEXO_ROOT:-}" ]; then
    echo "NEXO_ROOT=${NEXO_ROOT}"
  fi
} > "$OUT"

echo "export EVTX_HOST_PORT=${PARSER}"
echo "export AGENT_PORT=${AGENT}"
echo "export GUI_PORT=${AGENT}"
echo "export WORKSPACE_ROOT=${WS}"
[ -n "$KEEP_IMAGE" ] && echo "export EVTX_IMAGE=${KEEP_IMAGE}"
echo "# wrote ${OUT}" >&2
echo "# parser http://127.0.0.1:${PARSER}/  agent http://127.0.0.1:${AGENT}/" >&2
