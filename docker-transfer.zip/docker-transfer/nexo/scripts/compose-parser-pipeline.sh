#!/usr/bin/env bash
# Start the Poco/evtx parser app (default) and optionally the DepExtract agent.
#
#   bash scripts/compose-parser-pipeline.sh              # parser GUI only
#   WITH_EXTRACT_AGENT=1 bash scripts/compose-parser-pipeline.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

export WORKSPACE_ROOT="${WORKSPACE_ROOT:-$HOME/work}"
if [ -d "$ROOT/../poco" ]; then
  export POCO_CONTEXT="${POCO_CONTEXT:-$ROOT/../poco}"
elif [ -d "$WORKSPACE_ROOT/poco" ]; then
  export POCO_CONTEXT="${POCO_CONTEXT:-$WORKSPACE_ROOT/poco}"
else
  echo "error: set POCO_CONTEXT to the Poco/evtx checkout" >&2
  exit 1
fi

export OLLAMA_MODEL="${OLLAMA_MODEL:-codellama:7b}"
export AGENT_PORT="${AGENT_PORT:-${GUI_PORT:-5237}}"
export GUI_PORT="$AGENT_PORT" # backward-compat for older env files
export EVTX_HOST_PORT="${EVTX_HOST_PORT:-18080}"
WITH_EXTRACT_AGENT="${WITH_EXTRACT_AGENT:-0}"
mkdir -p "$WORKSPACE_ROOT/.dep-extract-out"

COMPOSE=(docker compose -f docker-compose.parser-pipeline.yml)

echo "WORKSPACE_ROOT=$WORKSPACE_ROOT"
echo "POCO_CONTEXT=$POCO_CONTEXT"
echo "Parser GUI (Poco/evtx) :$EVTX_HOST_PORT"
if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
  echo "Extract agent         :$AGENT_PORT  (profile extract-agent)"
fi

"${COMPOSE[@]}" build evtx
"${COMPOSE[@]}" up -d evtx
"${COMPOSE[@]}" --profile tools run --rm evtx-seed || true

if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
  "${COMPOSE[@]}" --profile extract-agent build
  "${COMPOSE[@]}" --profile extract-agent up -d
fi

echo
echo "Parser UI:  http://127.0.0.1:${EVTX_HOST_PORT}/"
echo "  health:"; curl -sS "http://127.0.0.1:${EVTX_HOST_PORT}/health"; echo
echo "  files:";  curl -sS "http://127.0.0.1:${EVTX_HOST_PORT}/files"; echo

if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
  echo
  echo "Extract agent (separate from parser UI): http://127.0.0.1:${AGENT_PORT}/"
  echo "  status:"; curl -sS "http://127.0.0.1:${AGENT_PORT}/api/status"; echo
  echo "  POST /api/run  (srcDir must be under $WORKSPACE_ROOT)"
else
  echo
  echo "Extract agent not started. Opt in with:"
  echo "  WITH_EXTRACT_AGENT=1 bash scripts/compose-parser-pipeline.sh"
fi
