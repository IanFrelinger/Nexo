#!/usr/bin/env bash
# Report whether a host TCP port looks busy (0=busy, 1=free).
# Used by pick-parser-pipeline-ports.sh and optional host-side probing from WSL.
#
#   bash scripts/probe-parser-pipeline-ports.sh 18080 && echo busy || echo free
set -euo pipefail

PORT="${1:?usage: $0 <port>}"

# Optional precomputed set: NEXO_HOST_BUSY_PORTS=18080,5237,8080
if [ -n "${NEXO_HOST_BUSY_PORTS:-}" ]; then
  case ",${NEXO_HOST_BUSY_PORTS}," in
    *",${PORT},"*) exit 0 ;;
  esac
fi

# Docker published host ports (host side of X->Y)
if command -v docker >/dev/null 2>&1; then
  if docker ps --format '{{.Ports}}' 2>/dev/null | grep -Eq ":${PORT}->"; then
    exit 0
  fi
fi

# Linux listeners
if command -v ss >/dev/null 2>&1; then
  if ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${PORT}$"; then
    exit 0
  fi
fi

# WSL can miss Windows-only binds — ask Windows when available.
if command -v powershell.exe >/dev/null 2>&1; then
  if powershell.exe -NoProfile -Command \
    "if (Get-NetTCPConnection -State Listen -LocalPort $PORT -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" \
    >/dev/null 2>&1; then
    exit 0
  fi
fi

# Bash /dev/tcp connect probe
if (echo >/dev/tcp/127.0.0.1/"$PORT") >/dev/null 2>&1; then
  exit 0
fi

exit 1
