#!/usr/bin/env bash
# Front-to-back E2E: mock proprietary EVTQ parser → agent plan/implement/install →
# evtx:custom image → extract a seeded mock .evtq and assert events were read.
#
# Prereqs (compose stack with extract-agent profile):
#   WORKSPACE_ROOT=$HOME/work POCO_CONTEXT=$HOME/work/poco \
#     docker compose -f docker-compose.parser-pipeline.yml --profile extract-agent up -d
#
#   bash scripts/e2e-parser-pipeline.sh
#
# Env:
#   AGENT_URL          default http://127.0.0.1:5237
#   POCO_CONTEXT       default $WORKSPACE_ROOT/poco or ../poco
#   WORKSPACE_ROOT     default $HOME/work
#   E2E_FILE           default tiny_smoke.evtq
#   E2E_MAX_EVENTS     default 25
#   E2E_CUSTOM_PORT    default 18081 (ephemeral custom parser; does not replace :18080)
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WS="${WORKSPACE_ROOT:-$HOME/work}"
POCO="${POCO_CONTEXT:-$WS/poco}"
AGENT_URL="${NEXO_DEPEXTRACT_GUI:-${AGENT_URL:-http://127.0.0.1:5237}}"
E2E_FILE="${E2E_FILE:-tiny_smoke.evtq}"
E2E_MAX_EVENTS="${E2E_MAX_EVENTS:-25}"
E2E_CUSTOM_PORT="${E2E_CUSTOM_PORT:-18081}"
FIX_SRC="$ROOT/src/Nexo.Bricks.DepExtract.Tests/Fixtures/e2e/MockEvtqParser"
DEST="$WS/proprietary-demo/MockEvtqParser"

die() { echo "error: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null || die "$1 not found"; }
need curl; need python3; need docker

[ -f "$FIX_SRC/MockEvtqStream.hpp" ] || die "missing fixture: $FIX_SRC/MockEvtqStream.hpp"
[ -f "$POCO/Dockerfile.custom" ] || die "POCO_CONTEXT missing Dockerfile.custom: $POCO"
[ -d "$POCO/common" ] || die "POCO_CONTEXT missing common/: $POCO"

WORKDIR="${WS}/.dep-extract-out/e2e-$$"
DATA="$WORKDIR/data"
mkdir -p "$DATA" "$DEST"
chmod 777 "$DATA" "$WORKDIR" || true
cleanup() {
  docker rm -f e2e-evtx-custom >/dev/null 2>&1 || true
  rm -rf "$WORKDIR"
}
trap cleanup EXIT

echo "== e2e: stage mock proprietary parser at $DEST =="
cp -a "$FIX_SRC/." "$DEST/"

echo "== e2e: agent status =="
curl -sf "$AGENT_URL/api/status" -o "$WORKDIR/status.json" || die "agent not reachable at $AGENT_URL"
python3 - "$WORKDIR/status.json" <<'PY'
import json,sys
s=json.load(open(sys.argv[1],encoding="utf-8"))
assert s.get("extractReady"), s
print("  extractReady ok; workspace=", s.get("workspaceRoot"))
PY

echo "== e2e: propose plan =="
python3 - <<PY > "$WORKDIR/plan_req.json"
import json
print(json.dumps({
  "srcDir": r"$DEST",
  "entries": ["MockEvtqStream.hpp"],
  "preferScaffold": True,
  "requireCompile": False,
}))
PY
curl -sf -X POST "$AGENT_URL/api/plan" -H "Content-Type: application/json" \
  --data-binary @"$WORKDIR/plan_req.json" -o "$WORKDIR/plan.json" \
  || die "POST /api/plan failed"
PLAN_ID=$(python3 -c "import json; print(json.load(open(r'$WORKDIR/plan.json'))['planId'])")
echo "  planId=$PLAN_ID"
python3 - "$WORKDIR/plan.json" <<'PY'
import json,sys
p=json.load(open(sys.argv[1],encoding="utf-8"))
assert p.get("strategy")=="scaffold", p.get("strategy")
print("  strategy=scaffold; risks=", len(p.get("risks") or []))
PY

echo "== e2e: revise with Must constraints =="
python3 - <<PY > "$WORKDIR/revise_req.json"
import json
print(json.dumps({
  "planId": "$PLAN_ID",
  "must": ["Drive next() from MockEvtqStream::advance reading the EVTQ file path"],
  "mustNot": ["Ignore the recording path / synthesize counter-only events"],
}))
PY
curl -sf -X POST "$AGENT_URL/api/plan/revise" -H "Content-Type: application/json" \
  --data-binary @"$WORKDIR/revise_req.json" -o "$WORKDIR/plan.json" \
  || die "POST /api/plan/revise failed"

echo "== e2e: implement approved plan =="
python3 - <<PY > "$WORKDIR/impl_req.json"
import json
print(json.dumps({
  "planId": "$PLAN_ID",
  "preferScaffold": True,
  "requireCompile": False,
}))
PY
curl -sf -X POST "$AGENT_URL/api/plan/implement" -H "Content-Type: application/json" \
  --data-binary @"$WORKDIR/impl_req.json" -o "$WORKDIR/impl.json" \
  || die "POST /api/plan/implement failed"
python3 - "$WORKDIR/impl.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
code=d.get("adapterCode") or ""
assert "CustomEventReader" in code, "missing CustomEventReader"
assert "MockEvtqStream" in code, "scaffold did not wire MockEvtqStream"
assert "MockEvtqStream>(path)" in code or "make_unique<MockEvtqStream>(path)" in code, code[:800]
open(sys.argv[1]+".code.hpp","w",encoding="utf-8").write(code)
print("  adapter lines=", code.count("\n")+1)
PY

echo "== e2e: install into Poco + rebuild evtx:custom (auto companions via planId) =="
python3 - <<PY > "$WORKDIR/install_req.json"
import json
print(json.dumps({
  "adapterCode": open(r"$WORKDIR/impl.json.code.hpp",encoding="utf-8").read(),
  "pocoContext": r"$POCO",
  "rebuildImage": True,
  "imageTag": "evtx:custom",
  "planId": "$PLAN_ID",
  "recreateEvtx": False,
}))
PY
curl -sf -X POST "$AGENT_URL/api/install" -H "Content-Type: application/json" \
  --data-binary @"$WORKDIR/install_req.json" -o "$WORKDIR/install.json" \
  || die "POST /api/install (rebuild) failed — see agent logs / install.json"
python3 - "$WORKDIR/install.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
assert d.get("imageTag")=="evtx:custom", d
comps=d.get("companionPaths") or []
assert any("MockEvtqStream.hpp" in (c or "") for c in comps), d
print("  installed", d.get("adaptedReaderPath"))
print("  imageTag", d.get("imageTag"))
print("  companions", len(comps))
PY
[ -f "$POCO/common/MockEvtqStream.hpp" ] || die "companion not written to poco/common"
[ -f "$POCO/common/adapted_reader.hpp" ] || die "adapted_reader.hpp missing"
grep -q MockEvtqStream "$POCO/common/adapted_reader.hpp" || die "adapted_reader does not reference MockEvtqStream"

echo "== e2e: seed $E2E_FILE into temp DATA_DIR =="
if docker image inspect evtx:latest >/dev/null 2>&1; then
  GEN_IMG=evtx:latest
elif docker image inspect evtx:custom >/dev/null 2>&1; then
  GEN_IMG=evtx:custom
else
  die "need evtx:latest or evtx:custom to generate mock recordings"
fi
# Prefer the image entrypoint "generate" helper (same as compose evtx-seed).
# Run as root so the bind-mounted host dir is writable regardless of image USER.
docker run --rm -u 0 -v "$DATA:/data" -e DATA_DIR=/data -e INDEX_DIR=/data \
  --entrypoint /app/docker-entrypoint.sh "$GEN_IMG" \
  generate "${E2E_FILE}:800:30" \
  || die "generate $E2E_FILE failed"
[ -f "$DATA/$E2E_FILE" ] || die "failed to generate $E2E_FILE (DATA=$DATA)"
ls -la "$DATA/$E2E_FILE"
chmod a+r "$DATA/$E2E_FILE" || true

echo "== e2e: run evtx:custom on :$E2E_CUSTOM_PORT =="
docker rm -f e2e-evtx-custom >/dev/null 2>&1 || true
docker run -d --name e2e-evtx-custom \
  -u 0 \
  -p "127.0.0.1:${E2E_CUSTOM_PORT}:8080" \
  -e DATA_DIR=/data -e INDEX_DIR=/data -e PORT=8080 \
  -v "$DATA:/data" \
  evtx:custom >/dev/null
EVTX_URL="http://127.0.0.1:${E2E_CUSTOM_PORT}"
for _ in $(seq 1 60); do
  if curl -sf "$EVTX_URL/health" >/dev/null; then break; fi
  sleep 0.25
done
curl -sf "$EVTX_URL/health" >/dev/null || die "evtx:custom /health failed"

echo "== e2e: inspect + extract $E2E_FILE via custom reader =="
ENC=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" "$E2E_FILE")
curl -sf "$EVTX_URL/inspect?file=$ENC" -o "$WORKDIR/inspect.json" || die "/inspect failed"
python3 - "$WORKDIR/inspect.json" <<'PY'
import json,sys
j=json.load(open(sys.argv[1],encoding="utf-8"))
fi=j.get("file") or j
count=fi.get("event_count") or fi.get("events") or fi.get("eventCount") or 0
print("  inspect event_count=", count)
assert int(count) > 0, j
PY

curl -sf -X POST "$EVTX_URL/extract?file=${ENC}&max_events=${E2E_MAX_EVENTS}" -o "$WORKDIR/job.json" \
  || die "/extract failed"
JOB_ID=$(python3 -c "import json; j=json.load(open(r'$WORKDIR/job.json')); print(j.get('id') or j.get('jobId') or j.get('job_id') or '')")
[ -n "$JOB_ID" ] || die "no job id: $(cat "$WORKDIR/job.json")"
echo "  job=$JOB_ID"
ok=0
for _ in $(seq 1 80); do
  curl -sf "$EVTX_URL/status?id=$JOB_ID" -o "$WORKDIR/job_status.json" || true
  STATE=$(python3 - "$WORKDIR/job_status.json" <<'PY'
import json,sys
try: j=json.load(open(sys.argv[1],encoding="utf-8"))
except Exception: print(""); raise SystemExit(0)
print((j.get("state") or j.get("status") or "").lower())
PY
)
  case "$STATE" in
    done|complete|completed|ok|success|finished) ok=1; break ;;
    failed|error) die "extract failed: $(cat "$WORKDIR/job_status.json")" ;;
  esac
  sleep 0.25
done
[ "$ok" = "1" ] || die "extract did not finish: $(cat "$WORKDIR/job_status.json" 2>/dev/null || true)"

# Status may not include a count — fetch /result CSV and count data rows.
curl -sf "$EVTX_URL/result?id=$JOB_ID" -o "$WORKDIR/result.csv" || die "/result failed"
python3 - "$WORKDIR/job_status.json" "$WORKDIR/result.csv" <<'PY'
import json,sys
j=json.load(open(sys.argv[1],encoding="utf-8"))
assert (j.get("state") or "").lower() in {"done","complete","completed","ok","success","finished"}, j
warns=int(j.get("warnings") or 0)
# Critical "unknown event type" would leave warnings high and empty results.
rows=open(sys.argv[2],encoding="utf-8",errors="replace").read().strip().splitlines()
data_rows=[r for r in rows[1:] if r.strip()] if rows else []
print("  result rows=", len(data_rows), "warnings=", warns, "degraded=", j.get("degraded"))
assert len(data_rows) > 0, {"status": j, "result_head": rows[:5]}
PY

echo "== e2e: PASS — mock parser adapted into Poco custom image and read $E2E_FILE =="
