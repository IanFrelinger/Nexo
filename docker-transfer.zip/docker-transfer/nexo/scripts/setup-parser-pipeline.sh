#!/usr/bin/env bash
# Short one-shot setup for the whole parser pipeline (Poco GUI + extract agent).
#
#   bash scripts/setup-parser-pipeline.sh          # up (default)
#   bash scripts/setup-parser-pipeline.sh down     # tear down
#   bash scripts/setup-parser-pipeline.sh status   # health + PIPELINE.md
#
# Env knobs:
#   WORKSPACE_ROOT / POCO_CONTEXT / NEXO_ROOT
#   AUTO_PORTS=1          pick free host ports (default 1)
#   WITH_EXTRACT_AGENT=1  start agent (default 1)
#   SKIP_OLLAMA=0         scaffold-only agent — no ollama containers (default 0)
#   SKIP_MODEL_PULL=1     don't wait on ollama pull (default 1; ignored if SKIP_OLLAMA=1)
#   SKIP_IF_HEALTHY=1     skip up when stack already healthy on chosen ports (default 1)
#   SEED=1 VERIFY=1 E2E=0 FORCE_RECREATE=0
#   COMPOSE_PROJECT       default nexo-parser-pipeline
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if grep -q $'\r' "$0" 2>/dev/null; then
  tmp="$(mktemp)"
  tr -d '\r' < "$0" > "$tmp"
  chmod +x "$tmp"
  exec bash "$tmp" "$@"
fi

CMD="${1:-up}"
shift || true

cd "$ROOT"

WORKSPACE_ROOT="${WORKSPACE_ROOT:-$HOME/work}"
NEXO_ROOT="${NEXO_ROOT:-$ROOT}"
AUTO_PORTS="${AUTO_PORTS:-1}"
WITH_EXTRACT_AGENT="${WITH_EXTRACT_AGENT:-1}"
SKIP_OLLAMA="${SKIP_OLLAMA:-0}"
SKIP_MODEL_PULL="${SKIP_MODEL_PULL:-1}"
SKIP_IF_HEALTHY="${SKIP_IF_HEALTHY:-1}"
SEED="${SEED:-1}"
VERIFY="${VERIFY:-1}"
E2E="${E2E:-0}"
FORCE_RECREATE="${FORCE_RECREATE:-0}"
COMPOSE_PROJECT="${COMPOSE_PROJECT:-nexo-parser-pipeline}"
OLLAMA_MODEL="${OLLAMA_MODEL:-codellama:7b}"
EVTX_IMAGE="${EVTX_IMAGE:-}"

die() { echo "error: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null || die "$1 not found"; }

need docker
need curl
docker info >/dev/null 2>&1 || die "docker daemon not reachable"

resolve_poco() {
  if [ -n "${POCO_CONTEXT:-}" ] && [ -d "$POCO_CONTEXT" ]; then return 0; fi
  if [ -d "$WORKSPACE_ROOT/poco" ]; then POCO_CONTEXT="$WORKSPACE_ROOT/poco"; return 0; fi
  if [ -d "$NEXO_ROOT/../poco" ]; then POCO_CONTEXT="$(cd "$NEXO_ROOT/../poco" && pwd)"; return 0; fi
  if [ -d "$NEXO_ROOT/../Poco" ]; then POCO_CONTEXT="$(cd "$NEXO_ROOT/../Poco" && pwd)"; return 0; fi
  die "set POCO_CONTEXT to the Poco/evtx checkout"
}

resolve_poco
[ -f "$POCO_CONTEXT/Dockerfile" ] || die "POCO_CONTEXT missing Dockerfile: $POCO_CONTEXT"
[ -f "$NEXO_ROOT/docker-compose.parser-pipeline.yml" ] || die "missing compose file in $NEXO_ROOT"

export WORKSPACE_ROOT POCO_CONTEXT OLLAMA_MODEL NEXO_ROOT COMPOSE_PROJECT
mkdir -p "$WORKSPACE_ROOT/.dep-extract-out"
ENV_FILE="${PARSER_PIPELINE_ENV:-$WORKSPACE_ROOT/parser-pipeline.env}"

ensure_ports() {
  if [ "$AUTO_PORTS" = "1" ] || [ ! -f "$ENV_FILE" ]; then
    echo "== pick free ports =="
    # shellcheck disable=SC1090
    eval "$(bash "$NEXO_ROOT/scripts/pick-parser-pipeline-ports.sh")"
  else
    # shellcheck disable=SC1090
    set -a; source "$ENV_FILE"; set +a
    export EVTX_HOST_PORT="${EVTX_HOST_PORT:-18080}"
    export AGENT_PORT="${AGENT_PORT:-${GUI_PORT:-5237}}"
    export GUI_PORT="$AGENT_PORT"
  fi
  export EVTX_HOST_PORT AGENT_PORT GUI_PORT
  ENV_FILE="${PARSER_PIPELINE_ENV:-$WORKSPACE_ROOT/parser-pipeline.env}"
  [ -f "$ENV_FILE" ] || die "missing env file: $ENV_FILE"
  upsert_env() {
    local key="$1" val="$2"
    if grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
      sed -i "s|^${key}=.*|${key}=${val}|" "$ENV_FILE"
    else
      echo "${key}=${val}" >> "$ENV_FILE"
    fi
  }
  if [ -n "$EVTX_IMAGE" ]; then
    upsert_env EVTX_IMAGE "$EVTX_IMAGE"
    export EVTX_IMAGE
  fi
  upsert_env COMPOSE_PROJECT "$COMPOSE_PROJECT"
  upsert_env NEXO_ROOT "$NEXO_ROOT"
}

write_pipeline_md() {
  local md="$WORKSPACE_ROOT/PIPELINE.md"
  cat > "$md" <<EOF
# Parser pipeline

| Surface | URL |
|---------|-----|
| Parser GUI | http://127.0.0.1:${EVTX_HOST_PORT}/ |
| Extract agent | $([ "$WITH_EXTRACT_AGENT" = "1" ] && echo "http://127.0.0.1:${AGENT_PORT}/" || echo "(not started)") |

- **Project:** \`$COMPOSE_PROJECT\`
- **Env file:** \`$ENV_FILE\`
- **Nexo:** \`$NEXO_ROOT\`
- **Poco:** \`$POCO_CONTEXT\`
- **EVTX_IMAGE:** \`${EVTX_IMAGE:-evtx:latest}\`
- **SKIP_OLLAMA:** \`$SKIP_OLLAMA\`

\`\`\`bash
# status
bash $NEXO_ROOT/scripts/setup-parser-pipeline.sh status

# tear down
bash $NEXO_ROOT/scripts/setup-parser-pipeline.sh down
\`\`\`
EOF
  echo "  wrote $md"
}

compose_base() {
  COMPOSE=(docker compose -p "$COMPOSE_PROJECT" -f "$NEXO_ROOT/docker-compose.parser-pipeline.yml" --env-file "$ENV_FILE")
  OVERRIDE=""
  if [ "$WITH_EXTRACT_AGENT" = "1" ] && [ "$SKIP_OLLAMA" = "1" ]; then
    OVERRIDE="$(mktemp -t nexo-pp-override.XXXXXX.yml)"
    cat > "$OVERRIDE" <<'YAML'
# Scaffold-only agent — no Ollama dependency.
services:
  dep-extract-agent:
    environment:
      PREFER_SCAFFOLD: "1"
    depends_on:
      dep-extract:
        condition: service_completed_successfully
YAML
    COMPOSE+=(-f "$OVERRIDE")
  elif [ "$WITH_EXTRACT_AGENT" = "1" ] && [ "$SKIP_MODEL_PULL" = "1" ]; then
    OVERRIDE="$(mktemp -t nexo-pp-override.XXXXXX.yml)"
    cat > "$OVERRIDE" <<'YAML'
services:
  dep-extract-agent:
    depends_on:
      dep-extract:
        condition: service_completed_successfully
      ollama:
        condition: service_healthy
YAML
    COMPOSE+=(-f "$OVERRIDE")
  fi
}

cleanup_override() { [ -n "${OVERRIDE:-}" ] && [ -f "$OVERRIDE" ] && rm -f "$OVERRIDE" || true; }

cmd_down() {
  ensure_ports
  compose_base
  trap cleanup_override EXIT
  echo "== down $COMPOSE_PROJECT =="
  "${COMPOSE[@]}" --profile extract-agent --profile tools --profile test down -v --remove-orphans || true
  echo "DOWN OK"
}

cmd_status() {
  ensure_ports
  echo "Parser : http://127.0.0.1:${EVTX_HOST_PORT}/"
  echo "Agent  : http://127.0.0.1:${AGENT_PORT}/"
  curl -sf "http://127.0.0.1:${EVTX_HOST_PORT}/health" && echo "  parser health OK" || echo "  parser health FAIL"
  curl -sf "http://127.0.0.1:${AGENT_PORT}/api/status" >/dev/null && echo "  agent status OK" || echo "  agent status FAIL"
  [ -f "$WORKSPACE_ROOT/PIPELINE.md" ] && echo "  PIPELINE.md present" || write_pipeline_md
}

stack_healthy() {
  curl -sf "http://127.0.0.1:${EVTX_HOST_PORT}/health" >/dev/null 2>&1 || return 1
  if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
    curl -sf "http://127.0.0.1:${AGENT_PORT}/api/status" >/dev/null 2>&1 || return 1
  fi
  return 0
}

wait_http() {
  local url="$1" label="$2" n="${3:-60}"
  local i
  for i in $(seq 1 "$n"); do
    if curl -sf "$url" >/dev/null 2>&1; then
      echo "  $label OK ($url)"
      return 0
    fi
    sleep 1
  done
  echo "  $label FAIL ($url)" >&2
  return 1
}

cmd_up() {
  echo "== setup-parser-pipeline =="
  echo "  NEXO_ROOT         = $NEXO_ROOT"
  echo "  WORKSPACE_ROOT    = $WORKSPACE_ROOT"
  echo "  POCO_CONTEXT      = $POCO_CONTEXT"
  echo "  COMPOSE_PROJECT   = $COMPOSE_PROJECT"
  echo "  WITH_EXTRACT_AGENT= $WITH_EXTRACT_AGENT"
  echo "  SKIP_OLLAMA       = $SKIP_OLLAMA"
  echo "  AUTO_PORTS        = $AUTO_PORTS"
  echo "  SKIP_IF_HEALTHY   = $SKIP_IF_HEALTHY"

  # Idempotent path: use existing env ports without re-picking.
  if [ "$SKIP_IF_HEALTHY" = "1" ] && [ "$FORCE_RECREATE" != "1" ] && [ -f "$ENV_FILE" ]; then
    set -a; # shellcheck disable=SC1090
    source "$ENV_FILE"; set +a
    export EVTX_HOST_PORT="${EVTX_HOST_PORT:-18080}"
    export AGENT_PORT="${AGENT_PORT:-${GUI_PORT:-5237}}"
    export GUI_PORT="$AGENT_PORT"
    if stack_healthy; then
      echo "== already healthy on :$EVTX_HOST_PORT / :$AGENT_PORT — skipping (FORCE_RECREATE=1 to force) =="
      write_pipeline_md
      echo "SETUP OK (idempotent)"
      echo "  Parser : http://127.0.0.1:${EVTX_HOST_PORT}/"
      [ "$WITH_EXTRACT_AGENT" = "1" ] && echo "  Agent  : http://127.0.0.1:${AGENT_PORT}/"
      return 0
    fi
  fi

  ensure_ports
  echo "  EVTX_HOST_PORT    = $EVTX_HOST_PORT"
  echo "  AGENT_PORT        = $AGENT_PORT"
  echo "  env file          = $ENV_FILE"

  compose_base
  trap cleanup_override EXIT

  UP_FLAGS=(-d --build)
  [ "$FORCE_RECREATE" = "1" ] && UP_FLAGS+=(--force-recreate)

  echo "== bring up parser GUI =="
  "${COMPOSE[@]}" up "${UP_FLAGS[@]}" evtx

  if [ "$SEED" = "1" ]; then
    echo "== seed demo recordings =="
    "${COMPOSE[@]}" --profile tools run --rm evtx-seed || echo "warn: seed failed (non-fatal)" >&2
  fi

  if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
    echo "== bring up extract agent =="
    if [ "$SKIP_OLLAMA" = "1" ]; then
      "${COMPOSE[@]}" --profile extract-agent up "${UP_FLAGS[@]}" dep-extract dep-extract-agent
    elif [ "$SKIP_MODEL_PULL" = "1" ]; then
      "${COMPOSE[@]}" --profile extract-agent up "${UP_FLAGS[@]}" dep-extract ollama dep-extract-agent
    else
      "${COMPOSE[@]}" --profile extract-agent up "${UP_FLAGS[@]}"
    fi
  fi

  echo "== URLs =="
  echo "  Parser GUI : http://127.0.0.1:${EVTX_HOST_PORT}/"
  if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
    echo "  Extract agent: http://127.0.0.1:${AGENT_PORT}/"
  fi

  FAIL=0
  if [ "$VERIFY" = "1" ]; then
    echo "== verify =="
    wait_http "http://127.0.0.1:${EVTX_HOST_PORT}/health" "parser /health" 45 || FAIL=1
    echo -n "  parser /files: "
    curl -sS "http://127.0.0.1:${EVTX_HOST_PORT}/files" || true
    echo
    if [ "$WITH_EXTRACT_AGENT" = "1" ]; then
      wait_http "http://127.0.0.1:${AGENT_PORT}/api/status" "agent /api/status" 60 || FAIL=1
      if curl -sf "http://127.0.0.1:${AGENT_PORT}/api/status" -o /tmp/nexo-agent-status.$$.json 2>&1; then
        if command -v python3 >/dev/null; then
          python3 - <<PY || FAIL=1
import json
s=json.load(open("/tmp/nexo-agent-status.$$.json",encoding="utf-8"))
print("  docker=", s.get("docker"), "extractReady=", s.get("extractReady"),
      "parserHostPort=", s.get("parserHostPort"), "agentHostPort=", s.get("agentHostPort"))
assert s.get("docker") is True, s
assert s.get("workspaceRoot"), "workspaceRoot missing"
assert int(s.get("parserHostPort") or 0) == int("$EVTX_HOST_PORT"), s
assert int(s.get("agentHostPort") or 0) == int("$AGENT_PORT"), s
PY
        fi
        rm -f /tmp/nexo-agent-status.$$.json
      fi
    fi
  fi

  if [ "$E2E" = "1" ]; then
    echo "== e2e =="
    export AGENT_URL="http://127.0.0.1:${AGENT_PORT}"
    export WORKSPACE_ROOT POCO_CONTEXT
    if [ -z "${E2E_CUSTOM_PORT:-}" ]; then
      E2E_CUSTOM_PORT=$((EVTX_HOST_PORT + 1000))
      [ "$E2E_CUSTOM_PORT" -lt 65535 ] || E2E_CUSTOM_PORT=19081
      export E2E_CUSTOM_PORT
    fi
    bash "$NEXO_ROOT/scripts/e2e-parser-pipeline.sh" || FAIL=1
  fi

  write_pipeline_md

  echo
  if [ "$FAIL" != "0" ]; then
    echo "SETUP FAILED"
    exit 1
  fi
  echo "SETUP OK"
  echo "  Parser : http://127.0.0.1:${EVTX_HOST_PORT}/"
  [ "$WITH_EXTRACT_AGENT" = "1" ] && echo "  Agent  : http://127.0.0.1:${AGENT_PORT}/"
  echo "  Env    : $ENV_FILE"
  echo "  Notes  : $WORKSPACE_ROOT/PIPELINE.md"
  echo "  Down   : bash $NEXO_ROOT/scripts/setup-parser-pipeline.sh down"
}

case "$CMD" in
  up|"") cmd_up ;;
  down) cmd_down ;;
  status) cmd_status ;;
  *) die "unknown command: $CMD (up|down|status)" ;;
esac
