# Parser pipeline — Getting Started (transfer bundle)

This zip is a **self-contained build context** for:

| Image | Role |
|-------|------|
| `evtx:latest` | Event Extract parser GUI (demo EVTQ reader) |
| `evtx:custom` | Same GUI compiled with your `adapted_reader.hpp` |
| `dep-extract:latest` | C++ `#include` dependency extractor |
| `nexo-dep-extract-agent` | Browser UI: plan → adapt → install (optional profile) |

## Prerequisites

- Docker Engine + Compose v2
- ~10–15 GB disk for base images (Ubuntu, .NET SDK, Ollama if used)
- A host directory for proprietary sources, e.g. `$HOME/work`

## Ports (when 18080 / 5237 are already taken)

```bash
# one-shot (auto-picks free ports, seeds, verifies, writes PIPELINE.md):
bash scripts/setup-parser-pipeline.sh
# or scaffold-only (no Ollama):
SKIP_OLLAMA=1 bash scripts/setup-parser-pipeline.sh
```

Manual:

```bash
export EVTX_HOST_PORT=28080 AGENT_PORT=15237
docker compose --env-file "$WORKSPACE_ROOT/parser-pipeline.env" up -d --force-recreate
```

In the agent UI: **Pick free ports** / **Apply** with **Recreate after save**, or **Recreate now**.

## 1. Unpack

```bash
mkdir -p ~/parser-pipeline && cd ~/parser-pipeline
unzip docker-transfer.zip        # or: tar -xzf docker-transfer.tar.gz
cd docker-transfer
```

## 2. Start (recommended one-shot)

```bash
export WORKSPACE_ROOT=$HOME/work
mkdir -p "$WORKSPACE_ROOT"
# from this docker-transfer folder:
export NEXO_ROOT="$(pwd)/nexo"
export POCO_CONTEXT="$(pwd)/poco"
bash nexo/scripts/setup-parser-pipeline.sh
# scaffold-only (no Ollama): SKIP_OLLAMA=1 bash nexo/scripts/setup-parser-pipeline.sh
```

Or compose directly from this folder:

```bash
docker compose up -d --build
docker compose --profile tools run --rm evtx-seed
```

Open **http://127.0.0.1:${EVTX_HOST_PORT:-18080}/** — live URLs also in `$WORKSPACE_ROOT/PIPELINE.md`.

## 3. Optional: extraction agent (plan / adapt / install)

```bash
export WORKSPACE_ROOT=$HOME/work
export POCO_CONTEXT="$(pwd)/poco"    # absolute path to this bundle's poco/
docker compose --profile extract-agent up -d --build
```

Open **http://127.0.0.1:5237/**

Put proprietary C++ under `$WORKSPACE_ROOT/...`, browse Source → Propose plan → revise → implement → Install (optionally rebuild `evtx:custom`).

## 4. Build the custom parser image (after Install wrote adapted_reader.hpp)

```bash
cd poco
docker build -f Dockerfile.custom -t evtx:custom .
# Run it (example):
docker run --rm -p 18081:8080 -v /path/to/recordings:/data -e DATA_DIR=/data evtx:custom
```

Or switch compose:

```bash
export EVTX_IMAGE=evtx:custom
docker compose up -d --build evtx
```

## 5. Proprietary binary chrono queue (production)

- Forward-only `next()` is enough — **seek is optional** (`can_resume` can stay false).
- Install must place proprietary headers next to `adapted_reader.hpp` (companion files).
- Validate against a **canned proprietary recording**, not demo `.evtq` files.

## Layout

```
docker-transfer/
  GETTING_STARTED.md          ← this file
  docker-compose.yml
  poco/                       ← build context for evtx / evtx:custom
  nexo/
    docker/dep-extract-gui/   ← agent Dockerfile
    tools/dep_extract/        ← dep-extract tool
    src/...                   ← agent .NET graph
```

## Quick health checks

```bash
curl -sf http://127.0.0.1:18080/health
curl -sf http://127.0.0.1:5237/api/status   # if agent profile is up
```

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Agent rejects srcDir | Path must be under `WORKSPACE_ROOT` |
| `evtx:custom` build fails | Ensure `poco/common/adapted_reader.hpp` (+ companions) exist |
| Ollama red in agent | Scaffold still works; start ollama profile or ignore for simple parsers |
| Port in use | Set `EVTX_HOST_PORT` / `AGENT_PORT`, or agent UI **Host ports** → Apply, then recreate |
