Parser pipeline Docker transfer bundle
======================================
See GETTING_STARTED.md for full directions.

Quick start:
  unzip docker-transfer.zip && cd docker-transfer
  export WORKSPACE_ROOT=$HOME/work
  mkdir -p "$WORKSPACE_ROOT"
  # if ports busy: export EVTX_HOST_PORT=28080 AGENT_PORT=15237
  docker compose up -d --build
  docker compose --profile tools run --rm evtx-seed
  # open http://127.0.0.1:${EVTX_HOST_PORT:-18080}/
