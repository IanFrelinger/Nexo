// evtx — event-file extraction service.
//   GET  /             the UI
//   GET  /files        list EVTB files in $DATA_DIR with header metadata
//   GET  /inspect?file=NAME    header details for one file
//   POST /upload?name=NAME     body = raw file bytes, written to $DATA_DIR/NAME
//   POST /extract?file=NAME&stride=&t0=&t1=&types=&fields=&max_events=
//   GET  /status?id=   GET /result?id=   GET /jobs   GET /health
// Files are selected by NAME ONLY and resolved against $DATA_DIR — request
// paths containing separators are rejected (no traversal by construction).
#include "Poco/Util/ServerApplication.h"
#include "Poco/Net/HTTPServer.h"
#include "Poco/Net/HTTPRequestHandler.h"
#include "Poco/Net/HTTPRequestHandlerFactory.h"
#include "Poco/Net/HTTPServerRequest.h"
#include "Poco/Net/HTTPServerResponse.h"
#include "Poco/Net/ServerSocket.h"
#include "Poco/URI.h"
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iostream>
#include "job_runner.hpp"
#include "sysinfo.hpp"
#include "pathsafe.hpp"
#ifdef NEXO_USE_QT
#include "qt_reader.hpp"
namespace { struct QtInit { QtInit(){ fileproc::use_qt_reader(); } } _nexo_qt_init; }  // route reads through Qt parser
#elif defined(NEXO_USE_CUSTOM)
// Drafted by Nexo CppParserAdapterBrick (scripts/adapt-parser-to-poco.sh).
// Review common/adapted_reader.hpp before shipping — it is a starting draft.
#include "adapted_reader.hpp"
namespace { struct CustomInit { CustomInit(){ fileproc::use_custom_reader(); } } _nexo_custom_init; }
#endif
#include "util.hpp"

using namespace Poco::Net;
namespace fs = std::filesystem;

static fs::path g_workdir = "/tmp/work";
static std::string env_or(const char* k, const char* def) { const char* v = std::getenv(k); return v ? v : def; }
static fs::path data_dir()   { return env_or("DATA_DIR", "/data"); }
static std::string static_dir() { return env_or("STATIC_DIR", "./static"); }

static std::map<std::string, std::string> query(const HTTPServerRequest& req) {
    std::map<std::string, std::string> q;
    for (auto& kv : Poco::URI(req.getURI()).getQueryParameters()) q[kv.first] = kv.second;
    return q;
}
static void json(HTTPServerResponse& r, int status, const std::string& body) {
    r.setStatus(static_cast<HTTPResponse::HTTPStatus>(status));
    r.setContentType("application/json");
    r.sendBuffer(body.data(), body.size());
}
static std::string json_escape(const std::string& s){
    std::string o; o.reserve(s.size()+8);
    for(char c: s){ switch(c){ case '"': o+="\\\""; break; case '\\': o+="\\\\"; break;
        case '\n': o+="\\n"; break; case '\r': break; case '\t': o+="\\t"; break; default: o+=c; } }
    return o;
}
static std::string json_warnings(const std::vector<std::string>& w, size_t cap=20){
    std::ostringstream s; s << "["; for(size_t i=0;i<w.size() && i<cap;++i)
        s << (i?",":"") << "\"" << json_escape(w[i]) << "\""; s << "]"; return s.str();
}
static std::string json_density(const std::vector<double>& v) {
    std::ostringstream s; s << "[";
    for (size_t i = 0; i < v.size(); ++i) s << (i ? "," : "") << (v[i] < 0 ? -1 : (long long)v[i]);
    s << "]"; return s.str();
}
static std::string json_types(const std::vector<std::string>& v) {
    std::ostringstream s; s << "[";
    for (size_t i = 0; i < v.size(); ++i) s << (i ? "," : "") << "\"" << v[i] << "\"";
    s << "]"; return s.str();
}

class Handler : public HTTPRequestHandler {
public:
    Handler(fileproc::JobRunner& r, std::string route) : runner_(r), route_(std::move(route)) {}
    void handleRequest(HTTPServerRequest& req, HTTPServerResponse& resp) override {
        if (route_ == "/health") { resp.setContentType("text/plain"); resp.send() << "ok"; return; }

        if (route_ == "/") {
            std::ifstream f(static_dir() + "/index.html", std::ios::binary);
            if (!f) { resp.setStatus(HTTPResponse::HTTP_NOT_FOUND); resp.send() << "index.html not found"; return; }
            resp.setContentType("text/html"); resp.send() << f.rdbuf(); return;
        }

        if (route_ == "/system") {
            auto dd = fileproc::disk_usage(data_dir());
            auto dw = fileproc::disk_usage(g_workdir);
            std::ostringstream js;
            js << "{\"disk_data\":{\"total\":" << dd.total << ",\"avail\":" << dd.avail << "}"
               << ",\"disk_work\":{\"total\":" << dw.total << ",\"avail\":" << dw.avail << "}"
               << ",\"rss\":" << fileproc::rss_bytes()
               << ",\"cpu_ticks\":" << fileproc::cpu_ticks()
               << ",\"hz\":" << fileproc::clock_hz() << "}";
            return json(resp, 200, js.str());
        }

        if (route_ == "/files") {
            std::ostringstream js; js << "["; bool first = true;
            std::error_code ec;
            for (auto& e : fs::directory_iterator(data_dir(), ec)) {
                // No extension filter: proprietary readers may use any extension —
                // inspect()'s own try/catch below is what decides "does this parse".
                if (!e.is_regular_file() || e.path().extension() == ".idx") continue;
                try {
                    auto fi = fileproc::inspect(e.path());
                    if (!first) js << ","; first = false;
                    js << "{\"name\":\"" << e.path().filename().string() << "\""
                       << ",\"bytes\":" << fi.bytes
                       << ",\"events\":" << fi.event_count
                       << ",\"t_begin\":" << fi.t_begin << ",\"t_end\":" << fi.t_end
                       << ",\"indexed_to\":" << fi.indexed_to_t << "}";
                } catch (...) { /* skip unreadable/foreign files */ }
            }
            js << "]"; return json(resp, 200, js.str());
        }

        auto q = query(req);

        if (route_ == "/inspect") {
            auto name = q.count("file") ? q["file"] : "";
            if (!fileproc::safe_name(name)) return json(resp, 400, R"({"error":"bad file name"})");
            try {
                auto fi = fileproc::inspect(data_dir() / name);
                std::ostringstream js;
                js << "{\"name\":\"" << name << "\",\"bytes\":" << fi.bytes
                   << ",\"events\":" << fi.event_count
                   << ",\"t_begin\":" << fi.t_begin << ",\"t_end\":" << fi.t_end
                   << ",\"indexed_to\":" << fi.indexed_to_t
                   << ",\"types\":" << json_types(fi.types)
                   << ",\"header_bytes\":" << fi.header_bytes
                   << ",\"payload_hint\":" << fi.payload_hint
                   << ",\"density\":" << json_density(fileproc::density_buckets(data_dir() / name)) << "}";
                return json(resp, 200, js.str());
            } catch (const std::exception& e) {
                return json(resp, 404, std::string("{\"error\":\"") + e.what() + "\"}");
            }
        }

        if (route_ == "/upload") {
            auto name = q.count("name") ? q["name"] : "";
            if (!fileproc::safe_name(name)) return json(resp, 400, R"({"error":"bad file name"})");
            auto path = data_dir() / name;
            {
                std::ofstream out(path, std::ios::binary | std::ios::trunc);
                if (!out) return json(resp, 500, R"({"error":"cannot open destination"})");
                out << req.stream().rdbuf();
                if (!out) { std::error_code ec; fs::remove(path, ec); return json(resp, 500, R"({"error":"write failed"})"); }
            }
            try {
                auto fi = fileproc::inspect(path);   // validates through whatever reader is active
                std::ostringstream js;
                js << "{\"name\":\"" << name << "\",\"bytes\":" << fi.bytes
                   << ",\"events\":" << fi.event_count
                   << ",\"t_begin\":" << fi.t_begin << ",\"t_end\":" << fi.t_end << "}";
                return json(resp, 200, js.str());
            } catch (const std::exception& e) {
                std::error_code ec; fs::remove(path, ec);   // don't leave unparseable junk in DATA_DIR
                return json(resp, 400, std::string("{\"error\":\"uploaded but failed to parse: ") + json_escape(e.what()) + "\"}");
            }
        }

        if (route_ == "/extract") {
            auto name = q.count("file") ? q["file"] : "";
            if (!fileproc::safe_name(name)) return json(resp, 400, R"({"error":"bad file name"})");
            auto path = data_dir() / name;
            if (!fs::exists(path)) return json(resp, 404, R"({"error":"no such file"})");
            fileproc::Params params; params.values = q;   // stride/t0/t1/types/fields/max_events
            auto id = runner_.submit(path, std::move(params));
            return json(resp, 202, "{\"id\":\"" + id + "\",\"status_url\":\"/status?id=" + id + "\"}");
        }

        if (route_ == "/jobs") {
            auto jobs = runner_.list();                 // newest-first
            // Live pipeline position: walk oldest-first, count pending jobs ahead.
            std::map<std::string,int> ahead;
            int pending = 0;
            for (auto it = jobs.rbegin(); it != jobs.rend(); ++it) {
                auto s = it->second.state;
                if (s == fileproc::State::Running) { ahead[it->first] = 0; pending = 1; }
                else if (s == fileproc::State::Queued) { ahead[it->first] = pending; ++pending; }
            }
            std::ostringstream js; js << "["; bool first = true;
            for (auto& [id, st] : jobs) {
                if (!first) js << ","; first = false;
                js << "{\"id\":\"" << id << "\",\"state\":\"" << fileproc::to_string(st.state)
                   << "\",\"progress\":" << st.progress;
                if (st.state == fileproc::State::Queued) js << ",\"ahead\":" << ahead[id];
                if (!st.warnings.empty()) js << ",\"warnings\":" << st.warnings.size();
                if (st.degraded) js << ",\"degraded\":true";
                if (st.state == fileproc::State::Failed) js << ",\"error\":\"" << json_escape(st.error) << "\"";
                js << "}";
            }
            js << "]"; return json(resp, 200, js.str());
        }

        auto id = q.count("id") ? q["id"] : "";
        if (id.empty()) return json(resp, 400, R"({"error":"missing id"})");
        auto st = runner_.query(id);
        if (!st) return json(resp, 404, R"({"error":"no such job"})");

        if (route_ == "/status") {
            std::ostringstream js;
            js << "{\"id\":\"" << id << "\",\"state\":\"" << fileproc::to_string(st->state)
               << "\",\"progress\":" << st->progress << ",\"ahead\":" << st->ahead;
            if (!st->warnings.empty()) js << ",\"warnings\":" << st->warnings.size()
                                          << ",\"warning_list\":" << json_warnings(st->warnings);
            if (st->degraded) js << ",\"degraded\":true";
            if (st->state == fileproc::State::Failed) js << ",\"error\":\"" << json_escape(st->error) << "\"";
            if (st->state == fileproc::State::Done)   js << ",\"result_url\":\"/result?id=" << id << "\"";
            js << "}";
            return json(resp, 200, js.str());
        }
        // /result
        if (st->state != fileproc::State::Done) return json(resp, 404, R"({"error":"not ready"})");
        resp.setStatus(HTTPResponse::HTTP_OK); resp.setContentType("text/csv");
        resp.set("Content-Disposition", "attachment; filename=\"" + id + ".csv\"");
        std::ifstream f(st->result, std::ios::binary); resp.send() << f.rdbuf();
    }
private:
    fileproc::JobRunner& runner_; std::string route_;
};

class Factory : public HTTPRequestHandlerFactory {
public:
    explicit Factory(fileproc::JobRunner& r) : runner_(r) {}
    HTTPRequestHandler* createRequestHandler(const HTTPServerRequest& req) override {
        const std::string p = Poco::URI(req.getURI()).getPath();
        if (req.getMethod() == "POST" && p == "/extract") return new Handler(runner_, "/extract");
        if (req.getMethod() == "POST" && p == "/upload")  return new Handler(runner_, "/upload");
        for (const char* r : {"/", "/files", "/inspect", "/jobs", "/status", "/result", "/health", "/system"})
            if (p == r) return new Handler(runner_, p);
        return new Handler(runner_, "/health");
    }
private:
    fileproc::JobRunner& runner_;
};

class App : public Poco::Util::ServerApplication {
protected:
    int main(const std::vector<std::string>&) override {
        fs::create_directories(g_workdir);
        fileproc::JobRunner runner(g_workdir);
        auto* params = new HTTPServerParams; params->setMaxThreads(4);
        HTTPServer server(new Factory(runner), ServerSocket(fileproc::port_from_env()), params);
        server.start();
        std::cerr << "evtx on :" << fileproc::port_from_env()
                  << "  data=" << data_dir() << "  ui=/" << "\n";
        waitForTerminationRequest();
        server.stop();
        return Application::EXIT_OK;
    }
};
POCO_SERVER_MAIN(App)
