#!/bin/sh
# entrypoint for the evtx image. Subcommands (first arg):
#   serve                  run the HTTP server (default)
#   generate [spec...]     write mock data files into DATA_DIR, then exit
#   clean [name...]        remove data files (+ their sidecar index) from DATA_DIR
#   submit key=val ...     POST /extract against the running server; prints the job id
#   status <id>            GET  /status?id=<id>
#   result <id>            GET  /result?id=<id>   (the extracted CSV)
#   jobs                   GET  /jobs
# Anything else is exec'd as-is, so `docker run evtx sh` etc. still work.
#
# generate accepts either form:
#   generate <name> <count> <duration_s>          legacy: one file, plain args
#   generate <spec> [<spec> ...]                   one or more files (a queue)
# where <spec> is  name[:size[:duration_s]]  and size is either a bare event
# count (2000000) or an approximate target file size (50MB, 1GB, 200KB — the
# actual byte size varies a bit since each record's field count is randomized).
# Examples:
#   generate exercise_alpha.evtq:2000000:600
#   generate small.evtq:5MB:60 medium.evtq:200MB:300 big.evtq:2GB:3600
#
# clean with no args wipes every file in DATA_DIR and every sidecar index in
# INDEX_DIR. clean <name...> removes just those files (+ matching .idx).
#
# submit/status/result/jobs talk to the *running server* over HTTP — they need
# SERVER_HOST (default "server", the compose service name) and PORT reachable.
set -e

DATA_DIR="${DATA_DIR:-/data}"
INDEX_DIR="${INDEX_DIR:-$DATA_DIR}"
SERVER_URL="http://${SERVER_HOST:-server}:${PORT:-8080}"
AVG_RECORD_BYTES=28   # 12B record header + avg 4 fields * 4B payload (see tools/gen_evtb.cpp)
HEADER_BYTES=64

# size_to_count SIZE -> echoes an event count on stdout
size_to_count() {
  size="$1"
  case "$size" in
    *[0-9][Gg][Bb])
      n="${size%[Gg][Bb]}"; echo $(( (n * 1000000000 - HEADER_BYTES) / AVG_RECORD_BYTES )) ;;
    *[0-9][Mm][Bb])
      n="${size%[Mm][Bb]}"; echo $(( (n * 1000000 - HEADER_BYTES) / AVG_RECORD_BYTES )) ;;
    *[0-9][Kk][Bb])
      n="${size%[Kk][Bb]}"; echo $(( (n * 1000 - HEADER_BYTES) / AVG_RECORD_BYTES )) ;;
    *)
      echo "$size" ;;                              # already a bare event count
  esac
}

# generate_one SPEC — SPEC is name[:size[:duration_s]]
generate_one() {
  spec="$1"
  case "$spec" in
    *:*:*) name="${spec%%:*}"; tmp="${spec#*:}"; size="${tmp%%:*}"; dur="${tmp#*:}" ;;
    *:*)   name="${spec%%:*}"; size="${spec#*:}"; dur="" ;;
    *)     name="$spec"; size=""; dur="" ;;
  esac

  size="${size:-2000000}"
  dur="${dur:-600}"
  count=$(size_to_count "$size")

  case "$name" in
    /*) out="$name" ;;                              # already absolute
    *)  out="$DATA_DIR/$name" ;;                    # bare name -> resolve against DATA_DIR
  esac
  mkdir -p "$(dirname "$out")"
  echo "generating $out  size=$size (events=$count)  duration=${dur}s"
  /app/gen_evtb "$out" "$count" "$dur"
}

# clean_one NAME — removes NAME from DATA_DIR and its sidecar index from INDEX_DIR
clean_one() {
  name="$1"
  case "$name" in
    /*) f="$name" ;;
    *)  f="$DATA_DIR/$name" ;;
  esac
  idx="$INDEX_DIR/$(basename "$f").idx"
  if [ -f "$f" ]; then echo "removing $f"; rm -f "$f"; else echo "skip (not found): $f" >&2; fi
  [ -f "$idx" ] && { echo "removing $idx"; rm -f "$idx"; }
}

case "$1" in
  serve|"")
    exec /app/evtx
    ;;

  generate)
    shift
    if [ "$#" -eq 0 ]; then
      set -- "demo.evtq:2000000:600"
    elif ! printf '%s\n' "$@" | grep -q ':'; then
      # legacy form: generate <name> <count> <duration_s>  (no colons anywhere -> one file)
      set -- "${1:-demo.evtq}:${2:-2000000}:${3:-600}"
    fi
    for spec in "$@"; do generate_one "$spec"; done
    ;;

  clean)
    shift
    if [ "$#" -eq 0 ]; then
      echo "cleaning all files in $DATA_DIR (and sidecar indexes in $INDEX_DIR)"
      find "$DATA_DIR" -maxdepth 1 -type f -print -delete
      [ "$INDEX_DIR" != "$DATA_DIR" ] && find "$INDEX_DIR" -maxdepth 1 -type f -name '*.idx' -print -delete
    else
      for name in "$@"; do clean_one "$name"; done
    fi
    ;;

  submit)
    shift
    if [ "$#" -eq 0 ]; then
      echo "usage: submit file=<name> [t0=] [t1=] [stride=] [types=] [fields=] [max_events=] [index_only=]" >&2
      exit 1
    fi
    qs=""
    for kv in "$@"; do qs="${qs}${qs:+&}${kv}"; done
    echo "POST $SERVER_URL/extract?$qs"
    resp=$(curl -sS -X POST "$SERVER_URL/extract?$qs")
    echo "$resp" | jq .
    id=$(echo "$resp" | jq -r '.id // empty')
    if [ -n "$id" ]; then
      echo "job id: $id"
      echo "  docker compose run --rm tools status $id"
      echo "  docker compose run --rm tools result $id"
    fi
    ;;

  status)
    shift
    curl -sS "$SERVER_URL/status?id=$1" | jq .
    ;;

  result)
    shift
    curl -sS "$SERVER_URL/result?id=$1"
    ;;

  jobs)
    curl -sS "$SERVER_URL/jobs" | jq .
    ;;

  *)
    exec "$@"
    ;;
esac
