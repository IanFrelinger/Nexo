// sysinfo.hpp — process + volume telemetry for the /system endpoint (Linux).
#pragma once
#include <sys/statvfs.h>
#include <unistd.h>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>

namespace fileproc {

struct DiskStat { uint64_t total = 0, avail = 0; };

inline DiskStat disk_usage(const std::filesystem::path& p) {
    struct statvfs s{};
    if (statvfs(p.c_str(), &s) == 0)
        return { s.f_blocks * (uint64_t)s.f_frsize, s.f_bavail * (uint64_t)s.f_frsize };
    return {};
}

inline uint64_t rss_bytes() {
    std::ifstream f("/proc/self/status");
    std::string l;
    while (std::getline(f, l))
        if (l.rfind("VmRSS:", 0) == 0) {
            std::istringstream ss(l.substr(6)); uint64_t kb = 0; ss >> kb; return kb * 1024;
        }
    return 0;
}

// utime+stime in clock ticks (fields 14/15 of /proc/self/stat, counted after
// the parenthesised comm field, which may itself contain spaces).
inline uint64_t cpu_ticks() {
    std::ifstream f("/proc/self/stat");
    std::string s; std::getline(f, s);
    auto p = s.rfind(')');
    if (p == std::string::npos) return 0;
    std::istringstream ss(s.substr(p + 2));
    std::string tok; uint64_t ut = 0, st = 0;
    for (int field = 3; field <= 15 && (ss >> tok); ++field) {
        if (field == 14) ut = std::stoull(tok);
        if (field == 15) st = std::stoull(tok);
    }
    return ut + st;
}

inline long clock_hz() { long h = sysconf(_SC_CLK_TCK); return h > 0 ? h : 100; }

} // namespace fileproc
