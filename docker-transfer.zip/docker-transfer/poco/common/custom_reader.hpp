// custom_reader.hpp — FILL-IN TEMPLATE for the PARSER SEAM.
// Copy this, implement the TODOs over your byte stream, then register it with
// use_custom_reader() in main(). Everything else in the service is untouched.
// See the STEP 1 / STEP 1b / STEP 2 / STEP 2b banners in processing.hpp for the
// full contract.
#pragma once
#include "processing.hpp"
#include <memory>

namespace fileproc {

class CustomEventReader : public IEventReader {
public:
    explicit CustomEventReader(const std::filesystem::path& path) {
        // TODO 1 — open `path`, read/skip any file header, seek to the first record.
        (void)path;
    }

    // Called once, before the scan, with the bare field names the caller asked for
    // (fields=name1,name2 — no offset/type, since those don't apply to your layout).
    // Only needed if your payload isn't a flat fixed-offset struct; skip this and
    // decodes_named_fields() otherwise and callers can keep using name:offset:type
    // against out.data like the demo format does.
    void set_requested_fields(const std::vector<std::string>& names) override {
        // TODO 2 — remember which named fields to decode per-record (e.g. store `names`).
        (void)names;
    }
    bool decodes_named_fields() const override { return true; }   // false = flat out.data + offsets instead

    // Yield ONE event. Lazy for flat formats: read the record header to learn its
    // length, copy at most `max_depth` payload bytes into out.data, and SKIP the
    // remainder. For non-flat formats, ignore max_depth/out.data and instead fill
    // out.fields[name] for each name from set_requested_fields() using whatever
    // logic your format needs (TLV, nested, variable-length, compressed, ...).
    bool next(Event& out, size_t max_depth) override {
        // TODO 3 — parse one record:
        //     out.t    = <timestamp>;                         // must be non-decreasing
        //     out.type = <type code>;                          // index into inspect()'s fi.types
        //     out.data = <first min(payload, max_depth) payload bytes>;   // flat formats
        //     out.fields["name"] = <decoded value as text>;              // non-flat formats
        //     advance the stream past the WHOLE record; keep pos_ in sync.
        //     return false at end-of-stream.
        (void)out; (void)max_depth;
        return false;
    }

    // Optional but recommended — enables the anchor index and fast time-windows.
    bool     can_resume() const override { return true; }
    uint64_t position()   const override { return pos_; }        // byte offset of NEXT record
    void     resume_at(uint64_t off) override { /* TODO 4 — seek to off */ pos_ = off; }

private:
    uint64_t pos_ = 0;
    // your stream/handle members here
};

// STEP 2b — your file-metadata inspector (event_count/t_begin/t_end/types/...).
// Not part of IEventReader: a header peek shouldn't require opening a full
// streaming reader. fi.types is authoritative — it drives process()'s type
// filter and the valid range for Event::type, so list every type code your
// format defines here, not just the demo's six.
inline FileInfo inspect_custom(const std::filesystem::path& path) {
    // TODO 5 — open `path`, read whatever header/metadata your format has, and
    // fill in FileInfo. Example shape:
    //     FileInfo fi;
    //     fi.event_count = ...; fi.t_begin = ...; fi.t_end = ...;
    //     fi.bytes = std::filesystem::file_size(path);
    //     fi.resumable = true;                 // matches CustomEventReader::can_resume()
    //     fi.types = {"YOUR_TYPE_0", "YOUR_TYPE_1", ...};
    //     return fi;
    (void)path;
    return FileInfo{};
}

// Call once in main() to route the whole service through your parser.
inline void use_custom_reader(){
    reader_factory() = [](const std::filesystem::path& p){
        return std::unique_ptr<IEventReader>(new CustomEventReader(p));
    };
    inspect_factory() = inspect_custom;
}

} // namespace fileproc
