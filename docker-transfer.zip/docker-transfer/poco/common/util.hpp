// util.hpp — tiny shared helpers so the three mains stay parallel.
#pragma once
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <string>

namespace fileproc {

inline int port_from_env(int fallback = 8080) {
    if (const char* p = std::getenv("PORT")) {
        try { return std::stoi(p); } catch (...) {}
    }
    return fallback;
}

// Server-chosen temp name. The client filename is NEVER used to build a path
// (that is the classic upload path-traversal vector).
inline std::filesystem::path unique_upload_path(const std::filesystem::path& dir) {
    static std::atomic<std::uint64_t> n{0};
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(
                  std::chrono::steady_clock::now().time_since_epoch()).count();
    return dir / ("upload-" + std::to_string(us) + "-" + std::to_string(n.fetch_add(1)));
}

} // namespace fileproc
