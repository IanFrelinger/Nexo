// msgbox_shim.hpp — headless replacement for the parser's QMessageBox calls.
// The desktop app popped modal dialogs; on the server those become warnings on
// the job (with severity). Integration is a mechanical rename at the call sites:
//
//     #include <QMessageBox>           ->   #include "msgbox_shim.hpp"
//     QMessageBox::warning(this,...)   ->   fileproc::MsgBox::warning(this,...)
//     QMessageBox::critical(this,...)  ->   fileproc::MsgBox::critical(this,...)
//
// warning/information -> Severity::Warning ; critical -> Severity::Critical.
// Accepts QString OR std::string OR const char* for title/text, and ignores the
// parent widget and any trailing button args, so existing call sites just compile.
#pragma once
#include "processing.hpp"
#include <string>
#include <utility>

namespace fileproc {

template<class T>
inline std::string mb_text(const T& v){
    if constexpr (requires { v.toStdString(); }) return v.toStdString();   // QString
    else return std::string(v);                                           // std::string / const char*
}

struct MsgBox {
    template<class Parent, class Title, class Text, class... Rest>
    static int warning(Parent&&, const Title& t, const Text& x, Rest&&...){
        current_warning_sink()(Severity::Warning,  mb_text(t)+": "+mb_text(x)); return 0; }
    template<class Parent, class Title, class Text, class... Rest>
    static int information(Parent&&, const Title& t, const Text& x, Rest&&...){
        current_warning_sink()(Severity::Warning,  mb_text(t)+": "+mb_text(x)); return 0; }
    template<class Parent, class Title, class Text, class... Rest>
    static int critical(Parent&&, const Title& t, const Text& x, Rest&&...){
        current_warning_sink()(Severity::Critical, mb_text(t)+": "+mb_text(x)); return 0; }
    template<class Parent, class Title, class Text, class... Rest>
    static int question(Parent&&, const Title& t, const Text& x, Rest&&...){
        current_warning_sink()(Severity::Warning,  mb_text(t)+": "+mb_text(x)); return 0; }
};

} // namespace fileproc
