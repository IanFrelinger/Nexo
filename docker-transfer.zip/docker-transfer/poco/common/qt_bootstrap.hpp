// qt_bootstrap.hpp — if the streamer's QThread uses a Qt EVENT LOOP or queued
// cross-thread signals, a headless QCoreApplication must exist (QApplication is
// GUI and needs a display; QCoreApplication does NOT). Instantiate ONE at startup.
// If the QThread is just a plain worker (run() does work, no exec(), no queued
// signals), you don't need this at all.
#pragma once
#ifdef NEXO_USE_QT
#include <QCoreApplication>
namespace fileproc {
inline void ensure_qt_core_app(){
    if(!QCoreApplication::instance()){
        static int argc = 1; static char name[] = "evtx"; static char* argv[] = { name, nullptr };
        static QCoreApplication app(argc, argv);   // headless; lives for process lifetime
    }
    // NOTE: constructing the app satisfies Qt APIs that require an instance. Queued
    // signal delivery still needs a running loop — either run app.exec() on a
    // dedicated thread, or (cleaner for a server) drop the QThread wrapper and run
    // the streamer's loop directly on the job worker via IEventReader::next().
}
}
#endif
