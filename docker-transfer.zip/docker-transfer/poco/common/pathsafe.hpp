// pathsafe.hpp — filename guard for name-only file resolution against DATA_DIR.
#pragma once
#include <string>
namespace fileproc {
inline bool safe_name(const std::string& n){
    return !n.empty() && n[0] != '.' &&
           n.find('/')  == std::string::npos &&
           n.find('\\') == std::string::npos;
}
}
