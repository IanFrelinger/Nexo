// processing.hpp — flexible-field / snapshot extraction over an opaque,
// chronologically-ordered binary event queue with a buffered, lazy reader.
// =====================================================================
//  Model:
//   - Each event has a known framing (timestamp + type) discovered by the
//     boundary scan; everything after is an OPAQUE payload.
//   - FIELDS are user-defined: (name, offset-in-payload, type). You tell the
//     parser what to pluck out of the payload buffer.
//   - With NO fields, the parser emits a SNAPSHOT: the first `snap` payload
//     bytes as hex — for inspecting raw records to learn the layout.
//   - LAZY LOADING: the reader materialises only up to `max_depth` payload
//     bytes per event (= deepest field, or snapshot length). Everything past
//     that is skipped, so shallow/sparse queries move far less data.
// =====================================================================
#pragma once
#include <cstdint>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fileproc {

struct Params {
    std::map<std::string, std::string> values;
    std::string get(const std::string& k, const std::string& def = "") const {
        auto it = values.find(k); return it == values.end() ? def : it->second;
    }
    double get_num(const std::string& k, double def) const {
        try { auto it = values.find(k); return it == values.end() ? def : std::stod(it->second); }
        catch (...) { return def; }
    }
};
using Progress = std::function<void(int)>;

// Warning channel. The desktop app pointed the parser's warnings at a GUI pane;
// headless, they flow here instead — to logs, the job's status, an audit trail.
// A thread_local "current sink" lets a global Qt message handler (see qt_reader.hpp)
// forward qWarning()/qCritical() into the running job without any GUI or event loop.
enum class Severity { Warning, Critical, Fatal };   // Warning=informational, Critical=degrade job, Fatal=fail job
using WarningSink = std::function<void(Severity, const std::string&)>;
inline WarningSink& current_warning_sink(){
    static thread_local WarningSink s = [](Severity,const std::string&){}; return s;
}
struct WarningScope {
    WarningSink prev;
    explicit WarningScope(WarningSink s){ prev=current_warning_sink();
        current_warning_sink() = s ? std::move(s) : WarningSink([](Severity,const std::string&){}); }
    ~WarningScope(){ current_warning_sink()=prev; }
};

// ---- field type system ----------------------------------------------------
enum class FType { U8,I8,U16,I16,U32,I32,U64,I64,F32,F64 };
inline size_t ftype_size(FType t){ switch(t){
    case FType::U8: case FType::I8: return 1; case FType::U16: case FType::I16: return 2;
    case FType::U32: case FType::I32: case FType::F32: return 4; default: return 8; } }
inline bool parse_ftype(const std::string& s, FType& out){
    static const std::map<std::string,FType> m = {{"u8",FType::U8},{"i8",FType::I8},
      {"u16",FType::U16},{"i16",FType::I16},{"u32",FType::U32},{"i32",FType::I32},
      {"u64",FType::U64},{"i64",FType::I64},{"f32",FType::F32},{"f64",FType::F64}};
    auto it=m.find(s); if(it==m.end()) return false; out=it->second; return true; }
struct FieldSpec { std::string name; size_t off=0; FType type=FType::U8; bool big_endian=false;
    bool by_name=false; };   // true => decoded by the reader itself (Event::fields), not flat offset math

inline std::string decode_field(const uint8_t* p, size_t avail, const FieldSpec& f){
    size_t sz = ftype_size(f.type);
    if (f.off + sz > avail) return "";                     // beyond materialised depth
    uint8_t buf[8]; std::memcpy(buf, p + f.off, sz);
    if (f.big_endian) std::reverse(buf, buf + sz);          // normalise to host little-endian
    auto rd = [&](auto tag){ decltype(tag) v; std::memcpy(&v,buf,sizeof v); return v; };
    std::ostringstream o;
    switch(f.type){
        case FType::U8:  o<<(unsigned)rd(uint8_t{}); break;   case FType::I8:  o<<(int)rd(int8_t{}); break;
        case FType::U16: o<<rd(uint16_t{}); break;            case FType::I16: o<<rd(int16_t{}); break;
        case FType::U32: o<<rd(uint32_t{}); break;            case FType::I32: o<<rd(int32_t{}); break;
        case FType::U64: o<<rd(uint64_t{}); break;            case FType::I64: o<<rd(int64_t{}); break;
        case FType::F32: o<<rd(float{}); break;               case FType::F64: o<<rd(double{}); break;
    }
    return o.str();
}
inline std::vector<FieldSpec> parse_fields(const std::string& s){
    std::vector<FieldSpec> v; std::stringstream ss(s); std::string tok;
    while(std::getline(ss,tok,',')){                        // name  OR  name:offset:type[:be|le]
        if(tok.empty()) continue;
        std::vector<std::string> parts; std::stringstream ps(tok); std::string pp;
        while(std::getline(ps,pp,':')) parts.push_back(pp);
        if(parts.size()==1){                                 // bare name: reader decodes this one itself
            FieldSpec f; f.name=parts[0]; f.by_name=true; v.push_back(f); continue;
        }
        if(parts.size()<3) continue;
        FieldSpec f; f.name=parts[0];
        try { f.off=(size_t)std::stoul(parts[1]); } catch(...){ continue; }
        if(!parse_ftype(parts[2], f.type)) continue;
        if(parts.size()>=4){ if(parts[3]=="be") f.big_endian=true; else if(parts[3]=="le") f.big_endian=false; else continue; }
        v.push_back(f);
    }
    return v;
}

// ---- opaque event + buffered lazy reader ---------------------------------
struct Event {
    double t=0; uint8_t type=0;
    std::vector<uint8_t> data;                       // flat payload up to depth (offset-decodable formats)
    std::map<std::string,std::string> fields;         // reader-decoded named values (non-flat formats; see STEP 1b)
};

struct FileInfo {
    uint64_t event_count=0; double t_begin=0,t_end=0; uint64_t bytes=0;
    double indexed_to_t=-1; bool resumable=false;
    size_t header_bytes=0, payload_hint=0;
    std::vector<std::string> types;                   // authoritative type taxonomy — supplied by inspect(), not fixed
};

// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ####################   PARSER SEAM · STEP 1 · THE CONTRACT   ############ ║
// ║                                                                          ║
// ║  YOUR PARSER IMPLEMENTS THIS INTERFACE — and nothing else in the service ║
// ║  changes: process(), the anchor index, the HTTP endpoints and the UI all ║
// ║  read through IEventReader and never know which parser is behind it.     ║
// ║                                                                          ║
// ║  Implement next(); implement position()/resume_at() too if your format   ║
// ║  supports seeking (that unlocks the anchor index + fast time-windows).   ║
// ║                                                                          ║
// ║  STEP 1b · non-flat payloads: if fields aren't fixed-offset primitives   ║
// ║  in a flat buffer (TLV, nested, variable-length, compressed, ...), don't ║
// ║  fight decode_field()'s offset math — decode them yourself. Override     ║
// ║  decodes_named_fields()=true and set_requested_fields(); next() then     ║
// ║  fills Event::fields directly using whatever logic your format needs.    ║
// ║  Callers request such fields by bare name (fields=speed,lat) instead of  ║
// ║  name:offset:type.                                                       ║
// ║                                                                          ║
// ║  Template: common/custom_reader.hpp   ·   Example: common/qt_reader.hpp  ║
// ╚══════════════════════════════════════════════════════════════════════════╝
class IEventReader {
public:
    virtual ~IEventReader()=default;
    virtual bool next(Event& out, size_t max_depth)=0;      // lazy: materialise <= max_depth payload bytes
    virtual bool can_resume() const { return false; }
    virtual uint64_t position() const { return 0; }
    virtual void resume_at(uint64_t) {}
    virtual void set_requested_fields(const std::vector<std::string>&) {}  // called once, before the scan
    virtual bool decodes_named_fields() const { return false; }            // true => next() fills Event::fields
};
std::unique_ptr<IEventReader> make_reader(const std::filesystem::path&);
FileInfo inspect(const std::filesystem::path&);
FileInfo inspect_evtq(const std::filesystem::path&);   // the demo format's own inspector; default inspect_factory()

// demo EVTQ: header "EVTQ",u32 ver,u64 count,f64 t0,f64 t1 (64B)
// record: [u8 type][u8 nf][u16 rsv][f64 t][nf x f32]  (payload = nf*4 bytes)
constexpr size_t   kHeaderSize=64, kRecHdr=12; constexpr uint64_t kIndexEveryN=10000;
inline const char* kTypeNames[]={"DETECTION","TRACK_UPDATE","EMISSION","NAV_STATE","COMMS","HEALTH"};  // EVTQ-only; see inspect_evtq()

// ┌──────────────────────────────────────────────────────────────────────────┐
// │  PARSER SEAM · REFERENCE IMPLEMENTATION  (this is the throwaway demo).     │
// │                                                                           │
// │  >>>>>>>>>>>>>>>>>>>>>>  REPLACE THIS WITH YOUR PARSER  <<<<<<<<<<<<<<<<<<< │
// │                                                                           │
// │  It parses the toy EVTQ format below. Your real reader goes in            │
// │  common/custom_reader.hpp (fill-in template) or common/qt_reader.hpp      │
// │  (working Qt/QDataStream example). Only next()'s framing logic differs.   │
// └──────────────────────────────────────────────────────────────────────────┘
class DemoQueueReader : public IEventReader {
public:
    explicit DemoQueueReader(const std::filesystem::path& p):in_(p,std::ios::binary){
        if(!in_) throw std::runtime_error("cannot open: "+p.string());
        in_.seekg(kHeaderSize); pos_=kHeaderSize;
    }
    bool next(Event& e, size_t max_depth) override {
        char h[kRecHdr];
        if(!in_.read(h,kRecHdr)) return false;
        uint8_t nf=(uint8_t)h[1]; e.type=(uint8_t)h[0]; std::memcpy(&e.t,h+4,8);
        size_t payload=(size_t)nf*4, take=std::min(payload,max_depth);
        e.data.resize(take);
        if(take) in_.read(reinterpret_cast<char*>(e.data.data()),take);
        if(payload>take) in_.seekg(payload-take,std::ios::cur);   // lazy: skip the rest
        pos_+=kRecHdr+payload;
        return (bool)in_;
    }
    bool can_resume() const override { return true; }
    uint64_t position() const override { return pos_; }
    void resume_at(uint64_t o) override { in_.clear(); in_.seekg(o); pos_=o; }
private:
    std::ifstream in_; uint64_t pos_=kHeaderSize;
};
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ####################   PARSER SEAM · STEP 2 · THE SWAP POINT  ########### ║
// ║                                                                          ║
// ║  EVERY read in the service goes through reader_factory(). To drop in     ║
// ║  YOUR parser, register it ONCE at startup — literally one line:          ║
// ║                                                                          ║
// ║      fileproc::reader_factory() = [](const std::filesystem::path& p){    ║
// ║          return std::unique_ptr<fileproc::IEventReader>(                 ║
// ║              new YourReader(p));                                          ║
// ║      };                                                                  ║
// ║                                                                          ║
// ║  (The Qt build does exactly this via use_qt_reader(); the template does  ║
// ║   it via use_custom_reader().)  Default below is the throwaway demo.     ║
// ╚══════════════════════════════════════════════════════════════════════════╝
using ReaderFactory = std::function<std::unique_ptr<IEventReader>(const std::filesystem::path&)>;
inline ReaderFactory& reader_factory(){
    static ReaderFactory f = [](const std::filesystem::path& p){
        return std::unique_ptr<IEventReader>(new DemoQueueReader(p)); };
    return f;
}
inline std::unique_ptr<IEventReader> make_reader(const std::filesystem::path& p){
    return reader_factory()(p);
}

// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ##############   PARSER SEAM · STEP 2b · THE METADATA SWAP POINT  ####### ║
// ║                                                                          ║
// ║  inspect() answers "what's in this file?" (event_count/t_begin/t_end/    ║
// ║  bytes/types) for /files, /inspect, and process()'s own t0/t1 defaults.  ║
// ║  It does NOT go through IEventReader — a header peek shouldn't require   ║
// ║  opening a full streaming reader — so it has its own swap point:         ║
// ║                                                                          ║
// ║      fileproc::inspect_factory() = [](const std::filesystem::path& p){   ║
// ║          fileproc::FileInfo fi; ...fill from YOUR header/metadata...;    ║
// ║          return fi;                                                      ║
// ║      };                                                                  ║
// ║                                                                          ║
// ║  fi.types is authoritative — process()'s type filter and event-type      ║
// ║  validity bound come from its size, not a fixed count. Default below is  ║
// ║  inspect_evtq(), the throwaway demo's own header parser.                 ║
// ╚══════════════════════════════════════════════════════════════════════════╝
using InspectFn = std::function<FileInfo(const std::filesystem::path&)>;
inline InspectFn& inspect_factory(){
    static InspectFn f = [](const std::filesystem::path& p){ return inspect_evtq(p); };
    return f;
}
inline FileInfo inspect(const std::filesystem::path& p){
    return inspect_factory()(p);
}

// ---- sidecar index (unchanged shape) -------------------------------------
inline std::filesystem::path idx_path(const std::filesystem::path& p){
    if(const char* d=std::getenv("INDEX_DIR")){ std::filesystem::create_directories(d);
        return std::filesystem::path(d)/(p.filename().string()+".idx"); }
    auto q=p; q+=".idx"; return q;
}
struct IndexEntry { double t; uint64_t off; };
inline std::vector<IndexEntry> load_index(const std::filesystem::path& d,double* upto=nullptr){
    std::vector<IndexEntry> v; std::ifstream f(idx_path(d),std::ios::binary); if(upto)*upto=-1;
    if(!f) return v; char h[32]; if(!f.read(h,32)||std::memcmp(h,"EVTI",4)!=0) return v;
    uint32_t ver; std::memcpy(&ver,h+4,4); if(ver!=2) return v;            // reject legacy/unknown versions
    double u; uint64_t n,fsize; std::memcpy(&u,h+8,8); std::memcpy(&n,h+16,8); std::memcpy(&fsize,h+24,8);
    std::error_code ec; uint64_t cur=std::filesystem::file_size(d,ec);
    if(ec || cur!=fsize) return v;                                         // stale: underlying file changed
    if(upto)*upto=u; v.resize(n);
    for(auto& e:v){ char b[16]; if(!f.read(b,16)){v.clear(); if(upto)*upto=-1; break;} std::memcpy(&e.t,b,8); std::memcpy(&e.off,b+8,8);} return v;
}
inline void save_index(const std::filesystem::path& d,const std::vector<IndexEntry>& v,double upto){
    std::ofstream f(idx_path(d),std::ios::binary|std::ios::trunc); if(!f) return;
    char h[32]={}; std::memcpy(h,"EVTI",4); uint32_t ver=2; std::memcpy(h+4,&ver,4);
    std::memcpy(h+8,&upto,8); uint64_t n=v.size(); std::memcpy(h+16,&n,8);
    std::error_code ec; uint64_t fsize=std::filesystem::file_size(d,ec); if(ec) fsize=0;
    std::memcpy(h+24,&fsize,8); f.write(h,32);
    for(auto& e:v){ char b[16]; std::memcpy(b,&e.t,8); std::memcpy(b+8,&e.off,8); f.write(b,16);} 
}
inline std::vector<double> density_buckets(const std::filesystem::path& p,int n=64){
    auto fi=inspect(p);                                  // t0/t1 come from the active inspector, not a raw header read
    double t0=fi.t_begin, t1=fi.t_end;
    double span=(t1-t0)>0?(t1-t0):1; std::vector<double> d(n,-1.0); auto idx=load_index(p);
    for(size_t i=0;i+1<idx.size();++i){ double ta=idx[i].t,tb=idx[i+1].t,dt=tb-ta; if(dt<=0)continue;
        double rate=(double)kIndexEveryN/dt; int b0=(int)((ta-t0)/span*n),b1=(int)((tb-t0)/span*n);
        for(int b=std::max(0,b0);b<=std::min(n-1,b1);++b) d[b]=d[b]<0?rate:(d[b]+rate)*0.5; }
    return d;
}
// The demo format's own inspector — parses the literal EVTQ header. Registered as
// inspect_factory()'s default; your inspect_factory() replacement doesn't need this shape at all.
inline FileInfo inspect_evtq(const std::filesystem::path& p){
    std::ifstream f(p,std::ios::binary); if(!f) throw std::runtime_error("cannot open: "+p.string());
    char hdr[kHeaderSize]; if(!f.read(hdr,kHeaderSize)) throw std::runtime_error("file too small");
    if(std::memcmp(hdr,"EVTQ",4)!=0) throw std::runtime_error("not an EVTQ file (bad magic)");
    FileInfo fi; std::memcpy(&fi.event_count,hdr+8,8); std::memcpy(&fi.t_begin,hdr+16,8); std::memcpy(&fi.t_end,hdr+24,8);
    fi.bytes=std::filesystem::file_size(p); fi.resumable=true; fi.header_bytes=kRecHdr;
    load_index(p,&fi.indexed_to_t);
    char rh[kRecHdr]; if(f.read(rh,kRecHdr)) fi.payload_hint=(size_t)(uint8_t)rh[1]*4;  // first record's payload size
    for(auto* n:kTypeNames) fi.types.push_back(n);
    return fi;
}

inline std::string to_hex(const std::vector<uint8_t>& b,size_t n){
    static const char* H="0123456789abcdef"; std::string s; n=std::min(n,b.size()); s.reserve(n*2);
    for(size_t i=0;i<n;++i){ s+=H[b[i]>>4]; s+=H[b[i]&15]; } return s;
}

// Params: stride | t0,t1 | types | max_events | fields="name:off:type,..." | snap=<bytes> | index_only
inline void process(const std::filesystem::path& input,const std::filesystem::path& output,
                    const Params& params,const Progress& progress, WarningSink warn = nullptr){
    WarningScope _ws(warn);
    FileInfo fi=inspect(input);
    uint64_t stride=(uint64_t)params.get_num("stride",1); if(stride<1)stride=1;
    double t0=params.get_num("t0",fi.t_begin), t1=params.get_num("t1",fi.t_end);
    uint64_t max_events=(uint64_t)params.get_num("max_events",0);
    const bool index_only=params.get_num("index_only",0)!=0;

    auto parse_csv=[](const std::string& s){ std::vector<std::string> v; std::stringstream ss(s); std::string t;
        while(std::getline(ss,t,',')) if(!t.empty()) v.push_back(t); return v; };
    std::vector<bool> type_on(fi.types.size()); { auto sel=parse_csv(params.get("types"));
        for(size_t i=0;i<fi.types.size();++i) type_on[i]=sel.empty();
        for(auto& s:sel) for(size_t i=0;i<fi.types.size();++i) if(s==fi.types[i]) type_on[i]=true; }

    auto fields=parse_fields(params.get("fields"));
    size_t snap=(size_t)params.get_num("snap", fields.empty()?16:0);
    // lazy depth: deepest flat-offset field end, or snapshot length (by_name fields don't consume .data)
    size_t depth=0; for(auto& f:fields) if(!f.by_name) depth=std::max(depth, f.off+ftype_size(f.type));
    if(fields.empty()) depth=snap;

    auto reader=make_reader(input);   // <<< PARSER SEAM: every read enters through here
    uint64_t header_off=reader->position();   // wherever the reader parked past its own header — format-agnostic
    { std::vector<std::string> names; for(auto& f:fields) if(f.by_name) names.push_back(f.name);
      if(!names.empty()) reader->set_requested_fields(names); }
    double indexed_to=-1; auto index=load_index(input,&indexed_to);
    { size_t lo=0,hi=index.size(); while(lo<hi){ size_t m=(lo+hi)/2; if(index[m].t<=t0)lo=m+1; else hi=m; }
      if(lo>0) reader->resume_at(index[lo-1].off); }
    uint64_t start_off=reader->position();
    bool grow_index=(index.empty()?true:start_off==index.back().off||start_off<=index.front().off);

    std::ofstream out(output,std::ios::binary); if(!out) throw std::runtime_error("cannot open output");
    out<<"t,type"; if(!index_only){ if(fields.empty()) out<<",bytes"; else for(auto& f:fields) out<<","<<f.name; }
    out<<"\n";

    Event e; uint64_t rec=0,kept=0; double last_t=indexed_to; int last_pct=-1; double seen_t=-1e300; int warncap=0;
    while(true){
        uint64_t pos=reader->position();
        if(!reader->next(e, index_only?0:depth)) break;    // index-only reads headers only
        if(e.t + 1e-9 < seen_t && warncap < 100){
            current_warning_sink()(Severity::Warning, "non-monotonic timestamp "+std::to_string(e.t)+" after "+std::to_string(seen_t));
            ++warncap;
        }
        seen_t = e.t;
        if(e.type >= fi.types.size() && warncap < 100){
            current_warning_sink()(Severity::Critical, "unknown event type "+std::to_string((int)e.type)+" at t="+std::to_string(e.t));
            ++warncap;
        }
        if(grow_index && e.t>last_t && (rec%kIndexEveryN)==0) index.push_back({e.t,pos});
        if(e.t>t1) break;                                   // chronological early exit
        if(!index_only && (rec%stride)==0 && e.t>=t0 && e.type<fi.types.size() && type_on[e.type]){
            out<<e.t<<","<<fi.types[e.type];
            if(fields.empty()) out<<","<<to_hex(e.data,snap);
            else for(auto& f:fields){
                out<<",";
                if(f.by_name){ auto it=e.fields.find(f.name); if(it!=e.fields.end()) out<<it->second; }
                else out<<decode_field(e.data.data(),e.data.size(),f);
            }
            out<<"\n";
            if(max_events && ++kept>=max_events) break;
        }
        ++rec; last_t=e.t;
        int pct=(int)((reader->position()-header_off)*100/((fi.bytes-header_off)?:1));
        if(pct!=last_pct){ last_pct=pct; progress(pct); }
    }
    if(grow_index && last_t>indexed_to) save_index(input,index,last_t);
    progress(100);
}

} // namespace fileproc
