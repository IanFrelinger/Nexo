// job_runner.hpp (GUI variant)
// Adds: params carried with each job, live progress (0..100) in status, and
// list() so the UI can show a jobs dashboard. Single-worker guarantee unchanged.
#pragma once
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <filesystem>
#include <mutex>
#include <optional>
#include <queue>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

#include "processing.hpp"

namespace fileproc {

namespace fs = std::filesystem;

enum class State { Queued, Running, Done, Failed };

inline const char* to_string(State s) {
    switch (s) {
        case State::Queued:  return "queued";
        case State::Running: return "running";
        case State::Done:    return "done";
        case State::Failed:  return "failed";
    }
    return "unknown";
}

struct JobStatus {
    State       state = State::Queued;
    std::string error;
    fs::path    result;
    int         ahead = 0;
    int         progress = 0;   // 0..100
    std::vector<std::string> warnings;   // parser diagnostics captured during the run
    bool        degraded = false;        // a Critical (or Fatal) warning fired during the run
};

class JobRunner {
public:
    explicit JobRunner(fs::path workdir)
        : workdir_(std::move(workdir)), worker_([this] { loop(); }) {}
    ~JobRunner() {
        { std::lock_guard lk(m_); stop_ = true; }
        cv_.notify_all(); worker_.join();
    }
    JobRunner(const JobRunner&) = delete;
    JobRunner& operator=(const JobRunner&) = delete;

    std::string submit(fs::path input, Params params) {
        auto id = "job-" + std::to_string(counter_.fetch_add(1));
        std::lock_guard lk(m_);
        int ahead = static_cast<int>(queue_.size()) + (running_ ? 1 : 0);
        status_[id] = JobStatus{State::Queued, "", {}, ahead, 0};
        order_.push_back(id);
        queue_.push(Job{id, std::move(input), std::move(params)});
        cv_.notify_one();
        return id;
    }

    std::optional<JobStatus> query(const std::string& id) {
        std::lock_guard lk(m_);
        if (auto it = status_.find(id); it != status_.end()) return it->second;
        return std::nullopt;
    }

    // Newest-first snapshot for the dashboard.
    std::vector<std::pair<std::string, JobStatus>> list() {
        std::lock_guard lk(m_);
        std::vector<std::pair<std::string, JobStatus>> out;
        for (auto it = order_.rbegin(); it != order_.rend(); ++it)
            out.emplace_back(*it, status_[*it]);
        return out;
    }

private:
    struct Job { std::string id; fs::path input; Params params; };

    void loop() {
        for (;;) {
            Job job;
            {
                std::unique_lock lk(m_);
                cv_.wait(lk, [this] { return stop_ || !queue_.empty(); });
                if (stop_ && queue_.empty()) return;
                job = std::move(queue_.front()); queue_.pop();
                running_ = true;
                status_[job.id].state = State::Running;
            }
            try {
                auto out = workdir_ / (job.id + ".result");
                // Progress callback updates status under the lock.
                auto report = [this, id = job.id](int pct) {
                    std::lock_guard lk(m_);
                    if (auto it = status_.find(id); it != status_.end()) it->second.progress = pct;
                };
                auto warn = [this, id = job.id](Severity sev, const std::string& msg) {
                    {
                        std::lock_guard lk(m_);
                        if (auto it = status_.find(id); it != status_.end() && it->second.warnings.size() < 500) {
                            const char* tag = sev==Severity::Fatal ? "[fatal] "
                                            : sev==Severity::Critical ? "[critical] " : "[warning] ";
                            it->second.warnings.push_back(std::string(tag) + msg);
                            if (sev != Severity::Warning) it->second.degraded = true;
                        }
                    }
                    if (sev == Severity::Fatal) throw std::runtime_error("fatal parser diagnostic: " + msg);
                };
                process(job.input, out, job.params, report, warn);   // <-- your processing.hpp
                std::lock_guard lk(m_);
                auto& s = status_[job.id];                 // update in place: keep warnings
                s.state = State::Done; s.result = out; s.progress = 100; s.ahead = 0; s.error.clear();
            } catch (const std::exception& e) {
                std::lock_guard lk(m_);
                status_[job.id].state = State::Failed;
                status_[job.id].error = e.what();
            }
            { std::lock_guard lk(m_); running_ = false; }
        }
    }

    fs::path                                    workdir_;
    std::mutex                                  m_;
    std::condition_variable                     cv_;
    std::queue<Job>                             queue_;
    std::vector<std::string>                    order_;   // submit order, for list()
    std::unordered_map<std::string, JobStatus>  status_;
    bool                                        stop_ = false;
    bool                                        running_ = false;
    std::atomic<uint64_t>                       counter_{1};
    std::thread                                 worker_;
};

} // namespace fileproc
