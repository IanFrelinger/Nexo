// qt_reader.hpp — adapter that plugs a Qt-based parser into the service's
// IEventReader seam. Compile the ONE translation unit that needs it with
// -DNEXO_USE_QT and Qt Core; the rest of the service stays Qt-free.
#pragma once
#ifdef NEXO_USE_QT
#include "processing.hpp"
#include <QByteArray>
#include <QDataStream>
#include <QFile>
#include <QString>
#include <QtGlobal>
#include <memory>
#include <stdexcept>

namespace fileproc {

class QtEventReader : public IEventReader {
public:
    explicit QtEventReader(const std::filesystem::path& p)
        : file_(QString::fromStdString(p.string())) {
        if (!file_.open(QIODevice::ReadOnly))
            throw std::runtime_error("Qt: cannot open " + p.string());
        stream_.setDevice(&file_);
        // EVTQ is little-endian. QDataStream DEFAULTS TO BIG-ENDIAN — the classic
        // Qt-parser gotcha, and the same endianness concern the field decoder handles.
        stream_.setByteOrder(QDataStream::LittleEndian);
        file_.seek(kHeaderSize);
        pos_ = kHeaderSize;
    }
    bool next(Event& e, size_t max_depth) override {
        if (file_.atEnd()) return false;
        quint8 type = 0, nf = 0; quint16 rsv = 0; double t = 0;
        stream_ >> type >> nf >> rsv >> t;
        if (stream_.status() != QDataStream::Ok) return false;
        const size_t payload = size_t(nf) * 4, take = std::min(payload, max_depth);
        e.type = type; e.t = t; e.data.resize(take);
        if (take) stream_.readRawData(reinterpret_cast<char*>(e.data.data()), int(take));
        if (payload > take) file_.seek(file_.pos() + qint64(payload - take));  // lazy skip
        pos_ += kRecHdr + payload;
        return true;
    }
    bool can_resume() const override { return true; }
    uint64_t position() const override { return pos_; }
    void resume_at(uint64_t off) override { file_.seek(qint64(off)); pos_ = off; }
private:
    QFile file_;
    QDataStream stream_;
    uint64_t pos_ = kHeaderSize;
};

inline std::unique_ptr<IEventReader> make_qt_reader(const std::filesystem::path& p){
    return std::unique_ptr<IEventReader>(new QtEventReader(p));
}
// Call this once at startup to route the whole service through the Qt parser:
// Bridge Qt's logging to the server's warning channel — no GUI, no QApplication.
inline void qt_message_bridge(QtMsgType type, const QMessageLogContext&, const QString& msg){
    switch(type){
        case QtWarningMsg:  current_warning_sink()(Severity::Warning,  msg.toStdString()); break;
        case QtCriticalMsg: current_warning_sink()(Severity::Critical, msg.toStdString()); break;
        case QtFatalMsg:    current_warning_sink()(Severity::Fatal,    msg.toStdString()); break;  // sink throws -> job fails, Qt never abort()s
        default: break;
    }
}
inline void use_qt_reader(){ reader_factory() = make_qt_reader; qInstallMessageHandler(qt_message_bridge); }

} // namespace fileproc
#endif // NEXO_USE_QT
