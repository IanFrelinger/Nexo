#!/usr/bin/env bash
# Structural headless guarantee: the server may link Qt5Core, but must NOT pull in
# any Qt GUI/Widgets or display stack. Wire into CI so a GUI dependency can never
# sneak back in when someone edits the parser.
set -u
bin="${1:?usage: no_gui_gate.sh <binary>}"
bad=$(ldd "$bin" 2>/dev/null | grep -iE 'qt5gui|qt5widgets|qt5quick|libx11|libxcb|libwayland|libgl\.so|libegl' || true)
if [ -n "$bad" ]; then
  echo "FAIL: $bin links GUI/display libraries — parser still coupled to the desktop app:"
  echo "$bad"; exit 1
fi
core=$(ldd "$bin" 2>/dev/null | grep -ic qt5core)
echo "OK: no GUI/display libs linked (Qt5Core linked: $core — headless)"
