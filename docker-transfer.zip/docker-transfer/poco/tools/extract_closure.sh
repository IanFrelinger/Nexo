#!/usr/bin/env bash
# extract_closure.sh — compute what a .cpp needs before lifting it out of a monorepo.
#
# Given the SOURCE and its REAL compile flags (best: pulled from compile_commands.json),
# it prints:
#   (1) the project-local header include closure  (the "lower" deps to copy),
#   (2) the undefined symbols it references, with Qt/GUI flagged and std noise removed
#       (first-party symbols = more .cpp to extract; Qt/3rd-party = get via Conan).
#
# Usage:
#   tools/extract_closure.sh <source.cpp> [-- <g++ flags: -I... -D... -std=...>]
# Tip: capture real flags first with `bear -- make` (or CMake
#      -DCMAKE_EXPORT_COMPILE_COMMANDS=ON), then copy this file's command line.
set -u
src="${1:?usage: extract_closure.sh <source.cpp> [-- <flags>]}"; shift || true
[ "${1:-}" = "--" ] && shift || true
flags="$*"
CXX="${CXX:-g++}"; STD="${STD:--std=c++20}"

echo "### include closure — project-local headers to copy (lower deps) ###"
$CXX $STD $flags -MM -MG "$src" 2>/dev/null \
  | tr ' \\' '\n\n' | grep -E '\.(h|hpp|hh|hxx|ipp)$' \
  | grep -vE '^/usr|/\.conan|/opt|^/lib' | sort -u | sed 's/^/  /'

echo
echo "### symbol closure — undefined references ###"
obj="$(mktemp --suffix=.o)"
if $CXX $STD $flags -c "$src" -o "$obj" 2>/tmp/ec.err; then
  und="$(nm -C -u "$obj" | sed 's/^[[:space:]]*U //' | sort -u)"
  echo "  total undefined: $(printf '%s\n' "$und" | grep -c .)"
  echo "  -- Qt / GUI symbols (MUST be empty for a headless server) --"
  q="$(printf '%s\n' "$und" | grep -E 'QMessageBox|QWidget|QApplication|QDialog|Q[A-Z][A-Za-z]+::')"
  [ -n "$q" ] && printf '%s\n' "$q" | sed 's/^/  !! /' || echo "     (none — headless-clean)"
  echo "  -- non-std candidates (likely first-party -> extract these definitions) --"
  printf '%s\n' "$und" | grep -vE '^std::|^__|^operator|^_Unwind|^_ZError|^mem(cpy|set|move)|^__cxa|^vtable|^typeinfo' \
    | grep -vE '^Q[A-Z]' | sed 's/^/     /' | head -60
else
  echo "  compile failed — usually a missing -I/-D. See /tmp/ec.err:"; head -6 /tmp/ec.err
fi
rm -f "$obj"

echo
echo "### resolve first-party symbols to their defining files (optional) ###"
echo "  # point BUILD_DIR at the monorepo's built objects, then:"
echo "  #   nm -C --defined-only --print-file-name \$BUILD_DIR/**/*.o | grep '<symbol>'"
echo "  # repeat for each pulled-in object's OWN undefined symbols = transitive closure."
