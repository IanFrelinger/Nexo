// gen_evtq: demo unstructured event queue.  gen <path> <events> <duration_s>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <random>
int main(int argc, char** argv) {
    if (argc < 4) return 1;
    uint64_t n = std::strtoull(argv[2], nullptr, 10);
    double dur = std::strtod(argv[3], nullptr);
    std::ofstream f(argv[1], std::ios::binary);
    char hdr[64] = {}; std::memcpy(hdr, "EVTQ", 4);
    uint32_t ver = 1; std::memcpy(hdr + 4, &ver, 4);
    std::memcpy(hdr + 8, &n, 8);
    double t0 = 0; std::memcpy(hdr + 16, &t0, 8);
    std::memcpy(hdr + 24, &dur, 8);
    f.write(hdr, 64);
    std::mt19937_64 rng(42);
    std::uniform_real_distribution<float> u(0.f, 1.f);
    for (uint64_t i = 0; i < n; ++i) {
        uint8_t nf = 2 + rng() % 5;              // 2..6 fields: variable size
        char rec[12 + 24];
        rec[0] = static_cast<char>(rng() % 6); rec[1] = static_cast<char>(nf);
        rec[2] = rec[3] = 0;
        double t = dur * i / n; std::memcpy(rec + 4, &t, 8);
        for (int k = 0; k < nf; ++k) { float v = u(rng) * 100.f; std::memcpy(rec + 12 + k*4, &v, 4); }
        f.write(rec, 12 + 4 * nf);
    }
}
